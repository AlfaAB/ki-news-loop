/* Automatisch erzeugt von tools/build-bundle.mjs. Nicht von Hand bearbeiten.
   Quelle der Wahrheit sind die JSON-Dateien unter data/weeks/.
   Stand: 2026-09-13T12:34:59.533Z */
window.KINEWS_BUNDLE = {
  "weeks": [
    {
      "schema": 1,
      "iso_week": "2026-W37",
      "year": 2026,
      "week": 37,
      "sent_date": "2026-09-13",
      "lead": "Gemini-Desktop-App für Windows: KI per Alt+Space über jedem Programm",
      "items": [
        {
          "id": "gemini-desktop-windows",
          "category": "tools",
          "title": "Gemini-Desktop-App für Windows: KI per Alt+Space über jedem Programm",
          "summary": "Google hat die Gemini-Desktop-App am 10. September global für Windows 10 und 11 veröffentlicht. Per Tastenkombination Alt + Space legt sich Gemini über das gerade geöffnete Programm – für schnelle Fragen, Umformulierungen oder Zusammenfassungen von Dokumenten, ohne den Tab oder das Fenster zu wechseln. Die App kann dabei auf Gmail und Google Drive zugreifen. Sie selbst lässt sich über gemini.google/desktop frei herunterladen; für Premium-Funktionen wie den Agenten Gemini Spark und die Videoerzeugung mit Gemini Omni ist laut Google ein kostenpflichtiges Google-AI-Abo nötig.",
          "relevance": {
            "studium": "Beim Lesen von PDFs, Schreiben in Word oder Recherchieren im Browser ist die KI-Hilfe einen Tastendruck entfernt, statt dass man Text in ein Browser-Tab kopieren muss.",
            "alltag": "Schnell installiert und systemweit per Tastenkürzel erreichbar – damit wird KI vom separaten Dienst zu einem normalen Bestandteil des Desktop-Workflows."
          },
          "source": {
            "url": "https://blog.google/innovation-and-ai/products/gemini-app/gemini-app-now-on-windows/",
            "name": "Google Blog"
          },
          "tags": [
            "google",
            "gemini",
            "windows",
            "desktop"
          ]
        },
        {
          "id": "meta-muse-personal-agent",
          "category": "alltag",
          "title": "Meta startet „Muse“: persönlicher KI-Agent, der Aufgaben wirklich ausführt",
          "summary": "Meta hat am 8. September Muse gestartet: einen persönlichen KI-Agenten, der Aufgaben nicht nur bespricht, sondern selbst ausführt. Der Start erfolgt zunächst nur in den USA. Laut Sensor Tower verzeichnete die App seit dem Launch über 83.000 iOS-Downloads in den USA und stand am 10. September auf Platz 2 der US-App-Charts, nach zuvor Platz 4 — gemessen an früheren Meta-Starts ist das allerdings ein eher verhaltener Auftakt. Damit ist Muse einer der sichtbarsten Versuche, KI-Agenten vom Entwickler-Thema zum Massenprodukt zu machen.",
          "relevance": {
            "studium": "Zeigt, wohin sich Assistenten entwickeln: weg vom Chat, hin zum Ausführen lästiger Organisationsaufgaben – nützlich zu wissen, auch wenn der Start vorerst auf die USA begrenzt ist.",
            "alltag": "Ein Agent eines großen Anbieters, der im Massenmarkt ankommt; in Deutschland ist er aber noch nicht verfügbar, und die Frage, wie viel Kontrolle über Konten und Daten man einem solchen Agenten abgibt, bleibt offen."
          },
          "source": {
            "url": "https://techcrunch.com/2026/09/10/metas-ai-agent-muse-is-now-the-no-2-app-in-the-us/",
            "name": "TechCrunch"
          },
          "tags": [
            "meta",
            "agenten",
            "app"
          ]
        },
        {
          "id": "fields-medalists-ai-math-warning",
          "category": "studium",
          "title": "25 Fields-Medaillen-Träger warnen vor KI in der Mathematik",
          "summary": "Am 11./12. September veröffentlichten 25 Fields-Medaillen-Gewinner – darunter Terence Tao, Peter Scholze, Maryna Viazovska, Cédric Villani und Pierre Deligne – eine gemeinsame Erklärung auf mathandai.org. Sie sehen eine „severe misalignment“ zwischen den Zielen der KI-Labore und denen der Mathematik: Problemlösen sei nur Mittel zum Zweck, das eigentliche Ziel sei konzeptuelles Verständnis. Benchmark-getriebene Massenproduktion von Lösungen untergrabe genau das und schaffe zusätzlich Probleme bei der Zuschreibung von Ergebnissen und beim Kompetenzaufbau von Nachwuchsforschenden. Die Erklärung fiel in dieselbe Woche wie OpenAIs umstrittene Ankündigung eines KI-Beweises zum Navier-Stokes-Problem, zu dem ein Plagiatsvorwurf im Raum steht.",
          "relevance": {
            "studium": "Das Argument „das Ringen mit einem Problem ist Teil der Ausbildung“ lässt sich direkt auf das eigene Lernen übertragen und ist ein brauchbarer Maßstab dafür, wann KI-Hilfe sinnvoll ist und wann sie das Verständnis ersetzt.",
            "alltag": "Eher nischig für den Alltag – aber ein nützlicher Gegenpol zur Erwartung, KI könne jede Denkarbeit abnehmen."
          },
          "source": {
            "url": "https://the-decoder.com/leading-mathematicians-fear-ai-is-making-their-field-dumber-and-warn-the-rest-of-us-is-next/",
            "name": "The Decoder"
          },
          "tags": [
            "mathematik",
            "forschung",
            "lernen"
          ]
        }
      ],
      "quick_hits": [
        {
          "id": "loqua-voice-typing",
          "title": "Loqua",
          "summary": "Diktier-App für Mac und Windows, die gesprochenes Gestammel live als sauber interpunktierten, bei Bedarf strukturierten Text direkt am Cursor einfügt – inklusive Übersetzung in fast 100 Sprachen und Screenshot-Fragen per „Capture to Ask“.",
          "source": {
            "url": "https://www.theloqua.ai/",
            "name": "theloqua.ai"
          },
          "tags": [
            "diktieren",
            "sprache"
          ]
        },
        {
          "id": "chatgpt-scheduled-tasks-webhooks",
          "title": "ChatGPT: Geplante Aufgaben per Webhook",
          "summary": "Scheduled Tasks in ChatGPT reagieren jetzt auf Ereignisse statt nur auf Uhrzeiten – etwa neue Gmail-Nachrichten, Slack-Kanalposts oder GitHub-Pull-Requests – und lassen sich teilen, womit einfache „wenn X, dann Y“-Automationen ohne Zapier möglich werden.",
          "source": {
            "url": "https://releasebot.io/updates/openai/chatgpt",
            "name": "Releasebot"
          },
          "tags": [
            "chatgpt",
            "automatisierung"
          ]
        },
        {
          "id": "switch-agents-in-team-chat",
          "title": "Switch",
          "summary": "Kostenlose, self-hostbare Open-Source-Brücke von SandboxAQ, die beliebige KI-Agenten als benannte Teilnehmer in Slack, Teams, Discord oder Telegram holt – praktisch für Studiengruppen oder WG-Chats.",
          "source": {
            "url": "https://www.producthunt.com/products/switch-11",
            "name": "Product Hunt"
          },
          "tags": [
            "open source",
            "agenten",
            "chat"
          ]
        }
      ]
    },
    {
      "schema": 1,
      "iso_week": "2026-W36",
      "year": 2026,
      "week": 36,
      "sent_date": "2026-09-05",
      "lead": "Google bringt Sprachsteuerung in Gmail, Docs und Keep",
      "items": [
        {
          "id": "google-live-voice-gmail-docs-keep",
          "category": "tools",
          "title": "Google bringt Sprachsteuerung in Gmail, Docs und Keep",
          "summary": "Google hat am 3. September die Funktionen „Gmail Live“, „Docs Live“ und „Keep Live“ ausgerollt. Damit lassen sich per Sprache Fragen zum Posteingang stellen, Dokumente diktieren oder ganze Entwürfe erzeugen lassen, mit Zugriff auf Gmail, Drive, Chat und Web, sowie Notizen und Listen freihändig anlegen. Die Features laufen auf iOS und Android, zunächst nur auf Englisch. Gmail Live ist für Google AI Plus/Pro/Ultra verfügbar, Docs Live und Keep Live für Pro/Ultra.",
          "relevance": {
            "studium": "Recherche-Notizen, Mail-Antworten an Dozierende oder erste Rohfassungen einer Hausarbeit lassen sich unterwegs einsprechen, statt sie am Laptop zu tippen.",
            "alltag": "Freihändiges Erfassen von Einkaufslisten, To-dos und Terminmails, praktisch beim Kochen, Pendeln oder Sport; für DACH aktuell aber nur mit englischer Bedienung nutzbar."
          },
          "source": {
            "url": "https://techcrunch.com/2026/09/03/google-launches-ai-voice-features-in-gmail-docs-and-keep/",
            "name": "TechCrunch",
            "published": "2026-09-03"
          },
          "tags": [
            "google",
            "gemini",
            "sprachsteuerung",
            "produktivität"
          ]
        },
        {
          "id": "anthropic-claude-campus-ambassador",
          "category": "studium",
          "title": "Anthropic öffnet Claude Campus Ambassador Program, Bewerbungsschluss 12. September",
          "summary": "Anthropic hat am 1. September die Bewerbung für das Claude Campus Ambassador Program geöffnet. Es gibt drei Tracks: Claude Builder Club für Bachelor-Studierende, Campus Conversations für Master-Studierende und Claude Science Workshops für PhDs und Postdocs. Ausgewählte Ambassadors erhalten ein Stipendium von 3.600 USD, API-Credits und Zugang zu Anthropic-Speakern. Die Laufzeit geht von September 2026 bis Juni 2027, Bewerbungsschluss ist der 12. September 2026, 23:59 PT.",
          "relevance": {
            "studium": "Ein konkretes, direkt zugängliches Angebot mit Stipendium und API-Credits. Wer Interesse hat, muss aber innerhalb der nächsten Tage entscheiden.",
            "alltag": "Eher nischig für den Alltag, abgesehen von den API-Credits für eigene Automatisierungsprojekte."
          },
          "source": {
            "url": "https://claude.com/programs/campus",
            "name": "Anthropic",
            "published": "2026-09-01"
          },
          "tags": [
            "anthropic",
            "claude",
            "stipendium",
            "frist"
          ],
          "deadline": "2026-09-12"
        },
        {
          "id": "android-feature-drop-september-2026",
          "category": "alltag",
          "title": "Android Feature Drop: Gemini merkt sich, wo Dinge liegen",
          "summary": "Der September-Feature-Drop für Android bringt mehrere neue KI-Funktionen. Über Find Hub kann man Gemini sagen, wo man etwas abgelegt hat („mein Reisepass liegt in der Schlafzimmerschublade“, optional mit Foto), und es später wieder abfragen. Motion Assist blendet unter Android 17 eine mitbewegte Blase ein, um Reiseübelkeit beim Handynutzen im Auto zu reduzieren. Guided Vision in Gemini Live beschreibt per Kamera die Umgebung für blinde und sehbehinderte Nutzer, und Google-Keep-Notizen lassen sich direkt in Google Messages gemeinsam bearbeiten.",
          "relevance": {
            "studium": "Gemeinsam bearbeitbare Keep-Notizen direkt im Chat erleichtern die Abstimmung in Lerngruppen und WG-Projekten ohne zusätzliche App.",
            "alltag": "Die Merkfunktion für abgelegte Gegenstände und Motion Assist auf Bus- und Bahnfahrten lösen sehr alltägliche Probleme direkt im Betriebssystem."
          },
          "source": {
            "url": "https://blog.google/products-and-platforms/platforms/android/android-drop-september-2026/",
            "name": "Google Blog",
            "published": "2026-09-03"
          },
          "tags": [
            "android",
            "gemini",
            "feature-drop",
            "barrierefreiheit"
          ]
        }
      ],
      "quick_hits": [
        {
          "id": "amazon-alexa-scam-check",
          "title": "Alexa for Shopping prüft Betrugsnachrichten",
          "summary": "Amazons Shopping-KI gleicht verdächtige Nachrichten zu Bestellungen, Prime-Verlängerungen oder Kontosperrungen mit Amazons eigenen Sendedaten ab und sagt, ob sie echt sind.",
          "source": {
            "url": "https://techcrunch.com/2026/09/02/psa-amazons-shopping-ai-can-now-tell-you-if-that-message-is-a-scam/",
            "name": "TechCrunch"
          },
          "tags": [
            "amazon",
            "sicherheit"
          ]
        },
        {
          "id": "sourclip-2-research-workspace",
          "title": "Sourclip",
          "summary": "Chrome-Erweiterung, die NotebookLM/Gemini Notebook zu einem Recherche-Workspace ausbaut: Quellen aus YouTube, Web, Reddit, X, PDFs und KI-Chats sammeln, in Ordnern und wiederverwendbaren Prompts organisieren, Mindmaps bearbeiten und nach Markdown, HTML oder PDF exportieren.",
          "source": {
            "url": "https://www.sourclip.com/",
            "name": "sourclip.com"
          },
          "tags": [
            "recherche",
            "notebooklm",
            "browser-erweiterung"
          ]
        },
        {
          "id": "google-ai-educator-deep-research-modul",
          "title": "Google AI Educator Series: neues Modul zu Gemini Deep Research",
          "summary": "Kostenloses Trainingsmodul, das zeigt, wie man Gemini Deep Research für wissenschaftliche Fragestellungen in Papers und Abschlussarbeiten einsetzt, plus Einführung in Guided Learning und virtueller Badge-a-thon am 19. September.",
          "source": {
            "url": "https://blog.google/products-and-platforms/products/education/new-ai-educator-trainings-september-2026/",
            "name": "Google Blog"
          },
          "tags": [
            "google",
            "deep-research",
            "lernen"
          ]
        }
      ],
      "archive_only": [
        {
          "id": "openai-astra-launch",
          "title": "OpenAI veröffentlicht neues Flaggschiff-Modell Astra, mächtig, aber umstritten",
          "source": {
            "url": "https://techcrunch.com/2026/09/03/openai-launches-astra-its-powerful-and-controversial-new-model/",
            "name": "TechCrunch"
          }
        },
        {
          "id": "google-gemini-student-hub",
          "title": "Google schenkt Studierenden ein Jahr Gemini AI Pro/Plus und startet neuen Student Hub",
          "source": {
            "url": "https://blog.google/innovation-and-ai/products/gemini-app/student-offer-google-ai/",
            "name": "Google Blog"
          }
        },
        {
          "id": "google-assistant-shutdown",
          "title": "Google Assistant wird abgeschaltet, Gemini übernimmt auf Android",
          "source": {
            "url": "https://9to5google.com/2026/08/04/google-assistant-september-2026-shutdown/",
            "name": "9to5Google"
          }
        }
      ]
    }
  ]
};
