/* ===========================================================================
   "Mit Claude vertiefen"

   Baut aus einem Themeneintrag und einer Vorlage aus config.js einen fertigen
   Prompt und öffnet damit eine neue Claude-Unterhaltung.

   Die URL-Länge ist der Haken: Browser und Server vertragen keine beliebig
   langen Query-Strings. Wird der Prompt zu lang, kürzen wir die
   Zusammenfassung, statt eine kaputte URL zu öffnen.
   =========================================================================== */

(function () {
  'use strict';

  var MAX_QUERY_CHARS = 1800;

  function fill(template, entry) {
    var categoryLabels = window.KINEWS_CATEGORIES || {};
    return template
      .replace(/\{\{titel\}\}/g, entry.title)
      .replace(/\{\{zusammenfassung\}\}/g, entry.summary || '(keine Zusammenfassung hinterlegt)')
      .replace(/\{\{quelle\}\}/g, entry.source.url || '(keine Quelle hinterlegt)')
      .replace(/\{\{kategorie\}\}/g, categoryLabels[entry.category] || entry.category);
  }

  function shorten(text, limit) {
    if (text.length <= limit) return text;
    var cut = text.slice(0, limit);
    var lastStop = Math.max(cut.lastIndexOf('. '), cut.lastIndexOf('\n'));
    return (lastStop > limit * 0.5 ? cut.slice(0, lastStop + 1) : cut) + ' [gekürzt]';
  }

  function buildPrompt(templateText, entry) {
    var prompt = fill(templateText, entry);
    if (encodeURIComponent(prompt).length <= MAX_QUERY_CHARS) return prompt;

    /* Zu lang: die Zusammenfassung ist der einzige Teil, der gekürzt werden
       darf. Titel und Quelle bleiben vollständig, sonst wird der Prompt
       unbrauchbar. */
    var trimmed = Object.assign({}, entry, {
      summary: shorten(entry.summary || '', 600)
    });
    return fill(templateText, trimmed);
  }

  function claudeUrl(prompt) {
    var base = (window.KINEWS_CONFIG && window.KINEWS_CONFIG.claudeBaseUrl) ||
      'https://claude.ai/new';
    return base + '?q=' + encodeURIComponent(prompt);
  }

  function templates() {
    return (window.KINEWS_CONFIG && window.KINEWS_CONFIG.claudePrompts) || [];
  }

  function templateById(id) {
    return templates().find(function (t) {
      return t.id === id;
    });
  }

  window.KINEWS_Claude = {
    templates: templates,
    templateById: templateById,
    buildPrompt: buildPrompt,
    url: claudeUrl
  };
})();
