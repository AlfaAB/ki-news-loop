/* ===========================================================================
   Kleine Bausteine: DOM-Helfer, Formatierung, Toast, Dialog, Popover.
   =========================================================================== */

(function () {
  'use strict';

  var MONTHS = [
    'Januar', 'Februar', 'März', 'April', 'Mai', 'Juni',
    'Juli', 'August', 'September', 'Oktober', 'November', 'Dezember'
  ];

  function esc(value) {
    return String(value == null ? '' : value)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function icon(name, fill) {
    return '<i class="' + (fill ? 'ph-fill ph-' : 'ph ph-') + name + '" aria-hidden="true"></i>';
  }

  function formatDate(iso) {
    if (!iso) return '';
    var parts = iso.split('-');
    if (parts.length < 3) return iso;
    return (
      parseInt(parts[2], 10) + '. ' + MONTHS[parseInt(parts[1], 10) - 1] + ' ' + parts[0]
    );
  }

  function formatDateShort(iso) {
    if (!iso) return '';
    var parts = iso.split('-');
    if (parts.length < 3) return iso;
    return parts[2] + '.' + parts[1] + '.' + parts[0];
  }

  function relativeWeeks(iso) {
    if (!iso) return '';
    var then = new Date(iso + 'T12:00:00');
    var days = Math.round((Date.now() - then.getTime()) / 86400000);
    if (days < 1) return 'heute';
    if (days === 1) return 'gestern';
    if (days < 7) return 'vor ' + days + ' Tagen';
    var weeks = Math.floor(days / 7);
    if (weeks === 1) return 'vor einer Woche';
    if (weeks < 9) return 'vor ' + weeks + ' Wochen';
    var months = Math.floor(days / 30);
    return 'vor ' + months + ' Monaten';
  }

  /* Treffer in der Suche hervorheben. Escaped zuerst, markiert danach, damit
     eingebettetes HTML aus den Daten nicht ausgeführt werden kann. */
  function highlight(text, query) {
    var safe = esc(text);
    if (!query) return safe;
    var terms = query
      .split(/\s+/)
      .filter(function (t) {
        return t.length > 1;
      })
      .map(function (t) {
        return t.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      });
    if (!terms.length) return safe;
    return safe.replace(new RegExp('(' + terms.join('|') + ')', 'gi'), '<mark>$1</mark>');
  }

  /* --- Toast -------------------------------------------------------------- */

  var toaster = null;

  function toast(message, iconName) {
    if (!toaster) {
      toaster = document.createElement('div');
      toaster.className = 'toaster';
      toaster.setAttribute('role', 'status');
      toaster.setAttribute('aria-live', 'polite');
      document.body.appendChild(toaster);
    }

    var node = document.createElement('div');
    node.className = 'toast';
    node.innerHTML = icon(iconName || 'check-circle', true) + '<span>' + esc(message) + '</span>';
    toaster.appendChild(node);

    /* Nächster Frame, damit der Übergang vom Startzustand aus läuft. */
    requestAnimationFrame(function () {
      node.dataset.visible = 'true';
    });

    var hide = setTimeout(function () {
      node.dataset.visible = 'false';
      setTimeout(function () {
        if (node.parentNode) node.parentNode.removeChild(node);
      }, 220);
    }, 2400);

    node.addEventListener('click', function () {
      clearTimeout(hide);
      node.dataset.visible = 'false';
      setTimeout(function () {
        if (node.parentNode) node.parentNode.removeChild(node);
      }, 220);
    });
  }

  /* --- Kurzer Druckimpuls auf Knöpfen ------------------------------------- */

  function pressPop(el) {
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    if (!el.animate) return;
    el.animate(
      [{ transform: 'scale(1)' }, { transform: 'scale(1.18)' }, { transform: 'scale(1)' }],
      { duration: 220, easing: 'cubic-bezier(0.23, 1, 0.32, 1)' }
    );
  }

  /* --- Popover ------------------------------------------------------------ */

  var openPopover = null;

  function closePopover() {
    if (!openPopover) return;
    if (openPopover.node.parentNode) {
      openPopover.node.parentNode.removeChild(openPopover.node);
    }
    if (openPopover.anchor) openPopover.anchor.setAttribute('aria-expanded', 'false');
    openPopover = null;
  }

  function showPopover(anchor, html, onSelect) {
    closePopover();

    var node = document.createElement('div');
    node.className = 'popover';
    node.setAttribute('role', 'menu');
    node.innerHTML = html;
    document.body.appendChild(node);

    var rect = anchor.getBoundingClientRect();
    var width = node.offsetWidth;
    var height = node.offsetHeight;

    /* Am Auslöser ausrichten, aber im Viewport bleiben. */
    var left = Math.min(rect.left, window.innerWidth - width - 14);
    left = Math.max(14, left);
    var flipUp = rect.bottom + height + 12 > window.innerHeight && rect.top > height;
    var top = flipUp ? rect.top - height - 7 : rect.bottom + 7;

    node.style.left = left + window.scrollX + 'px';
    node.style.top = top + window.scrollY + 'px';
    node.style.setProperty(
      '--transform-origin',
      (flipUp ? 'bottom ' : 'top ') + (rect.left - left + rect.width / 2) + 'px'
    );

    anchor.setAttribute('aria-expanded', 'true');
    openPopover = { node: node, anchor: anchor };

    node.addEventListener('click', function (event) {
      var item = event.target.closest('[data-value]');
      if (!item) return;
      var value = item.dataset.value;
      closePopover();
      onSelect(value);
    });

    var first = node.querySelector('button');
    if (first) first.focus();
  }

  document.addEventListener('click', function (event) {
    if (!openPopover) return;
    if (openPopover.node.contains(event.target)) return;
    if (openPopover.anchor.contains(event.target)) return;
    closePopover();
  });

  document.addEventListener('keydown', function (event) {
    if (event.key === 'Escape' && openPopover) {
      var anchor = openPopover.anchor;
      closePopover();
      anchor.focus();
    }
  });

  window.addEventListener('resize', closePopover);

  /* --- Dialog ------------------------------------------------------------- */

  function dialog(options) {
    var node = document.createElement('dialog');
    node.innerHTML =
      '<form method="dialog">' +
      '<div class="dialog__head">' +
      '<div><h2>' + esc(options.title) + '</h2>' +
      (options.description ? '<p>' + esc(options.description) + '</p>' : '') +
      '</div></div>' +
      '<div class="dialog__body">' + (options.body || '') + '</div>' +
      '<div class="dialog__foot">' + (options.footer || '') + '</div>' +
      '</form>';

    document.body.appendChild(node);
    node.addEventListener('close', function () {
      if (options.onClose) options.onClose(node.returnValue, node);
      /* Nach der Schließ-Animation aufräumen. */
      setTimeout(function () {
        if (node.parentNode) node.parentNode.removeChild(node);
      }, 60);
    });
    node.showModal();

    var focusTarget = node.querySelector('[data-autofocus]');
    if (focusTarget) {
      focusTarget.focus();
      if (focusTarget.select) focusTarget.select();
    }

    /* Für Dialoge, die vor dem Schließen etwas Asynchrones erledigen müssen
       (Anmeldung) und dabei Fehler im Dialog zeigen sollen, statt ihn zu
       schließen und neu zu öffnen. */
    if (options.onReady) options.onReady(node);
    return node;
  }

  /* Fehlerzeile im Dialog setzen oder leeren. */
  function dialogError(node, message) {
    var slot = node.querySelector('.form-error');
    if (!slot) return;
    slot.textContent = message || '';
    slot.hidden = !message;
  }

  function setBusy(button, busy, label) {
    button.disabled = busy;
    if (busy) {
      button.dataset.idleLabel = button.textContent;
      button.textContent = label || 'Moment…';
    } else if (button.dataset.idleLabel) {
      button.textContent = button.dataset.idleLabel;
    }
  }

  function copyText(text) {
    if (navigator.clipboard && window.isSecureContext) {
      return navigator.clipboard.writeText(text);
    }
    /* http://localhost ist secure, file:// nicht. Fallback für den Rest. */
    return new Promise(function (resolve, reject) {
      var area = document.createElement('textarea');
      area.value = text;
      area.style.position = 'fixed';
      area.style.opacity = '0';
      document.body.appendChild(area);
      area.select();
      try {
        document.execCommand('copy');
        resolve();
      } catch (err) {
        reject(err);
      }
      document.body.removeChild(area);
    });
  }

  window.KINEWS_UI = {
    esc: esc,
    icon: icon,
    formatDate: formatDate,
    formatDateShort: formatDateShort,
    relativeWeeks: relativeWeeks,
    highlight: highlight,
    toast: toast,
    pressPop: pressPop,
    showPopover: showPopover,
    closePopover: closePopover,
    dialog: dialog,
    dialogError: dialogError,
    setBusy: setBusy,
    copyText: copyText
  };
})();
