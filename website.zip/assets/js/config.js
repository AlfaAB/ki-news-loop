/* ---------------------------------------------------------------------------
   KI-News-Radar - Konfiguration
   Die einzige Datei, die du anfassen musst, um das Backend zu aktivieren.
   --------------------------------------------------------------------------- */

window.KINEWS_CONFIG = {
  /* Titel in Kopfzeile und Browser-Tab. */
  siteName: 'KI-News-Radar',

  /* --------------------------------------------------------------------
     Woher die Wochendaten kommen, in dieser Reihenfolge versucht:

     1. Das GitHub-Repo der Routine. Dort landet jede neue Ausgabe direkt
        nach dem Lauf; die Website zeigt sie spätestens fünf Minuten später,
        so lange hält GitHub die Dateien zwischengespeichert.
     2. Der Ordner data/ auf deinem Server, als Rückfall, falls GitHub gerade
        nicht erreichbar ist. Er ist nur so aktuell wie dein letzter Upload,
        die Website weist dann darauf hin.
     -------------------------------------------------------------------- */
  dataSources: [
    'https://raw.githubusercontent.com/AlfaAB/ki-news-loop/main/data/',
    'data/'
  ],

  /* --------------------------------------------------------------------
     Speicher für Markierungen, Notizen und Erledigt-Status.

     'local'    – localStorage, pro Browser getrennt. Funktioniert sofort,
                  ohne Konto, ohne Netz. Standard.
     'supabase' – Supabase-Tabelle, gerätübergreifend. Erfordert die
                  Felder unten UND das SQL aus supabase/schema.sql.

     Fällt der Backend-Zugriff aus, schaltet die App automatisch auf
     'local' zurück und zeigt das in der Statusanzeige an.
     -------------------------------------------------------------------- */
  storage: 'supabase',

  supabase: {
    /* Nur die Project URL, ohne Pfad dahinter, z. B.
       'https://abcdefghijk.supabase.co'. Nicht den RESTful endpoint mit
       /rest/v1/ am Ende, den setzt die App selbst zusammen. */
    url: 'https://rnazxzwwfmtcvtbspsbv.supabase.co',
    /* Der öffentliche anon-Key aus Project Settings > API. */
    anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJuYXp4end3Zm10Y3Z0YnNwc2J2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODkyNDQ4OTcsImV4cCI6MjEwNDgyMDg5N30.uKy6pLj--1HquE1zB_Wm9vBaee8Gj9Ac6JLt5ZyHTnE',
    /* Tabellenname aus supabase/schema.sql. */
    table: 'marks',
    /*
      Zugriffsmodus:
      'auth' – empfohlen. Anmeldung mit E-Mail und Passwort direkt in der App,
               wahlweise auch per Magic Link. Row Level Security bindet jede
               Zeile an auth.uid(), nur du siehst deine Markierungen.
               Das Konto legst du einmalig im Supabase-Dashboard an.
      'open' – kein Login. Der anon-Key steht im Quelltext jeder ausgelieferten
               Seite; wer ihn hat, kann alle Zeilen lesen und schreiben, auch
               von außerhalb deines Servers. Nur wählen, wenn dir das für diese
               Daten egal ist.
    */
    mode: 'auth'
  },

  /* --------------------------------------------------------------------
     Vorlagen für "Mit Claude vertiefen".
     {{titel}}, {{zusammenfassung}}, {{quelle}} und {{kategorie}} werden
     beim Klick ersetzt.
     -------------------------------------------------------------------- */
  claudePrompts: [
    {
      id: 'einordnen',
      label: 'Einordnen und prüfen',
      hint: 'Was steckt dahinter, was ist Marketing?',
      text:
        'Ich habe folgende KI-Meldung in meinem wöchentlichen News-Digest gelesen:\n\n' +
        'Titel: {{titel}}\n' +
        'Zusammenfassung: {{zusammenfassung}}\n' +
        'Quelle: {{quelle}}\n\n' +
        'Ordne das bitte für mich ein. Was ist daran wirklich neu, was ist ' +
        'Marketing, und wie belastbar ist die Quelle? Nenne, falls es sie gibt, ' +
        'zwei bis drei konkurrierende oder ergänzende Angebote und sag mir, wo ' +
        'die Meldung in einem Jahr vermutlich steht.'
    },
    {
      id: 'studium',
      label: 'Fürs Studium nutzen',
      hint: 'Konkreter Arbeitsablauf statt Featureliste',
      text:
        'Kontext: Ich bin Student und lese wöchentlich einen KI-News-Digest.\n\n' +
        'Titel: {{titel}}\n' +
        'Zusammenfassung: {{zusammenfassung}}\n' +
        'Quelle: {{quelle}}\n\n' +
        'Zeig mir bitte einen konkreten Arbeitsablauf, wie ich das im Studium ' +
        'einsetzen kann: Recherche, Literaturarbeit, Mitschriften oder ' +
        'Prüfungsvorbereitung. Keine Featureliste, sondern Schritt für Schritt ' +
        'an einem realistischen Beispiel. Nenne auch, wo es Grenzen gibt und ' +
        'worauf ich bei Quellenangaben und Prüfungsordnung achten muss.'
    },
    {
      id: 'umsetzen',
      label: 'Selbst umsetzen',
      hint: 'Ausprobieren oder nachbauen',
      text:
        'Titel: {{titel}}\n' +
        'Zusammenfassung: {{zusammenfassung}}\n' +
        'Quelle: {{quelle}}\n\n' +
        'Ich möchte das selbst ausprobieren oder etwas Vergleichbares nachbauen. ' +
        'Führ mich bitte durch die ersten Schritte: was ich brauche, was es ' +
        'kostet, welche Alternativen es gibt und welche Stolperfallen in den ' +
        'ersten 30 Minuten typisch sind. Frag mich vorher nach allem, was du ' +
        'über mein Setup wissen musst.'
    },
    {
      id: 'kritisch',
      label: 'Gegenposition suchen',
      hint: 'Risiken, Kritik, Datenschutz',
      text:
        'Titel: {{titel}}\n' +
        'Zusammenfassung: {{zusammenfassung}}\n' +
        'Quelle: {{quelle}}\n\n' +
        'Such mir bitte die Gegenposition zu dieser Meldung. Welche Kritik gibt ' +
        'es, welche Risiken bei Datenschutz und Abhängigkeit, und was sagen ' +
        'Leute, die dem Ganzen skeptisch gegenüberstehen? Sei explizit, wenn du ' +
        'zu einem Punkt nichts Belastbares findest.'
    }
  ],

  /* Basis-URL für neue Claude-Unterhaltungen. */
  claudeBaseUrl: 'https://claude.ai/new'
};
