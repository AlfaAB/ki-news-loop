/* ===========================================================================
   Markierungen, Notizen, Erledigt-Status.

   Zwei Adapter hinter einer Schnittstelle:
     LocalAdapter    - localStorage, sofort einsatzbereit
     SupabaseAdapter - REST gegen Supabase, gerätübergreifend, mit Anmeldung

   Der Store hält immer eine vollständige Kopie im Speicher, damit die
   Oberfläche synchron rendern kann. Schreibvorgänge gehen optimistisch durch
   und werden im Hintergrund persistiert. Ist das Backend nicht erreichbar
   oder die Anmeldung abgelaufen, arbeitet der Store lokal weiter und macht
   das sichtbar, statt Eingaben zu verlieren.
   =========================================================================== */

(function () {
  'use strict';

  var LOCAL_KEY = 'kinews.marks.v1';
  var SESSION_KEY = 'kinews.session.v1';

  function markKey(week, itemId) {
    return week + '::' + itemId;
  }

  function emptyMark(week, itemId) {
    return {
      key: markKey(week, itemId),
      iso_week: week,
      item_id: itemId,
      marked: false,
      done: false,
      note: '',
      updated_at: new Date().toISOString()
    };
  }

  /* Nur die Felder, die in der Tabelle stehen. user_id setzt Postgres selbst
     über den Vorgabewert auth.uid(), deshalb wird es nie mitgeschickt. */
  function payload(mark) {
    return {
      key: mark.key,
      iso_week: mark.iso_week,
      item_id: mark.item_id,
      marked: !!mark.marked,
      done: !!mark.done,
      note: mark.note || '',
      updated_at: mark.updated_at
    };
  }

  function readJson(store, key) {
    try {
      return JSON.parse(store.getItem(key) || 'null');
    } catch (err) {
      return null;
    }
  }

  function writeJson(store, key, value) {
    try {
      if (value === null) store.removeItem(key);
      else store.setItem(key, JSON.stringify(value));
    } catch (err) {
      /* Privater Modus oder blockierte Site-Daten. Die Sitzung läuft weiter,
         nur ohne Persistenz. */
    }
  }

  /* --- Adapter: localStorage --------------------------------------------- */

  function LocalAdapter() {
    this.name = 'local';
  }

  LocalAdapter.prototype.load = function () {
    return Promise.resolve(readJson(localStorage, LOCAL_KEY) || {});
  };

  LocalAdapter.prototype.persist = function (all) {
    writeJson(localStorage, LOCAL_KEY, all);
    return Promise.resolve();
  };

  LocalAdapter.prototype.save = function (mark, all) {
    return this.persist(all);
  };

  LocalAdapter.prototype.remove = function (key, all) {
    return this.persist(all);
  };

  /* --- Adapter: Supabase -------------------------------------------------- */

  /* Das Dashboard zeigt neben der Project URL auch den RESTful endpoint
     (…/rest/v1/). Wird der eingetragen, landen alle Anfragen unter
     …/rest/v1/auth/v1/… und Supabase antwortet mit "Invalid path specified
     in request URL". Die Projekt-Adresse ist immer nur der Ursprung, also
     alles hinter Domain und Port abschneiden. */
  function projectBase(url) {
    var raw = String(url || '').trim();
    if (!/^https?:\/\//i.test(raw)) raw = 'https://' + raw;
    try {
      return new URL(raw).origin;
    } catch (err) {
      return raw.replace(/\/+$/, '');
    }
  }

  function SupabaseAdapter(cfg) {
    this.name = 'supabase';
    this.cfg = cfg;
    this.base = projectBase(cfg.url);
    this.endpoint = this.base + '/rest/v1/' + cfg.table;
    this.session = null;
    this.refreshing = null;

    if (cfg.mode === 'auth') {
      this.captureHashSession();
      if (!this.session) this.session = readJson(localStorage, SESSION_KEY);
    }
  }

  /* Nach einem Magic-Link-Klick hängt Supabase die Tokens als Fragment an.
     Das kollidiert mit den Hash-Routen der App, also gleich einsammeln und
     die Adresszeile aufräumen. */
  SupabaseAdapter.prototype.captureHashSession = function () {
    var hash = window.location.hash || '';
    if (hash.indexOf('access_token=') === -1) return;

    var params = new URLSearchParams(hash.replace(/^#/, ''));
    var token = params.get('access_token');
    if (!token) return;

    this.storeSession({
      access_token: token,
      refresh_token: params.get('refresh_token'),
      expires_in: params.get('expires_in')
    });
    history.replaceState(null, '', window.location.pathname + '#/');
  };

  /* Aus dem JWT brauchen wir nur exp und email. Beides ist unkritisch, die
     Signatur prüft ohnehin der Server. */
  function decodeJwt(token) {
    try {
      var part = token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/');
      var raw = atob(part);
      var utf8 = decodeURIComponent(
        raw
          .split('')
          .map(function (c) {
            return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
          })
          .join('')
      );
      return JSON.parse(utf8);
    } catch (err) {
      return null;
    }
  }

  SupabaseAdapter.prototype.storeSession = function (data) {
    var claims = decodeJwt(data.access_token) || {};
    this.session = {
      access_token: data.access_token,
      refresh_token: data.refresh_token || (this.session && this.session.refresh_token) || '',
      /* expires_at liefert Supabase beim Token-Endpunkt mit, beim Magic-Link
         nur expires_in. Der Wert aus dem JWT ist der verlässlichste. */
      expires_at:
        claims.exp ||
        data.expires_at ||
        Math.floor(Date.now() / 1000) + (Number(data.expires_in) || 3600),
      email: (data.user && data.user.email) || claims.email || ''
    };
    writeJson(localStorage, SESSION_KEY, this.session);
    return this.session;
  };

  SupabaseAdapter.prototype.clearSession = function () {
    this.session = null;
    writeJson(localStorage, SESSION_KEY, null);
  };

  SupabaseAdapter.prototype.needsLogin = function () {
    return this.cfg.mode === 'auth' && !this.session;
  };

  SupabaseAdapter.prototype.accountLabel = function () {
    return (this.session && this.session.email) || '';
  };

  SupabaseAdapter.prototype.headers = function (extra) {
    var token = (this.session && this.session.access_token) || this.cfg.anonKey;
    var h = {
      apikey: this.cfg.anonKey,
      Authorization: 'Bearer ' + token,
      'Content-Type': 'application/json'
    };
    if (extra) {
      Object.keys(extra).forEach(function (k) {
        h[k] = extra[k];
      });
    }
    return h;
  };

  function authFetch(base, path, anonKey, body) {
    return fetch(base + path, {
      method: 'POST',
      headers: { apikey: anonKey, 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    }).catch(function () {
      /* fetch wirft bei DNS-, Netz- und CORS-Fehlern nur "Failed to fetch".
         Das hilft niemandem weiter, deshalb hier etwas Verwertbares. */
      throw new Error(
        'Supabase ist nicht erreichbar. Prüfe die URL in config.js und deine ' +
          'Internetverbindung.'
      );
    }).then(function (res) {
      return res.json().then(
        function (data) {
          if (!res.ok) {
            throw new Error(
              data.error_description ||
                data.msg ||
                data.message ||
                data.error ||
                'Anmeldung fehlgeschlagen (' + res.status + ')'
            );
          }
          return data;
        },
        function () {
          throw new Error('Unerwartete Antwort von Supabase (' + res.status + ')');
        }
      );
    });
  }

  SupabaseAdapter.prototype.signInWithPassword = function (email, password) {
    var self = this;
    return authFetch(this.base, '/auth/v1/token?grant_type=password', this.cfg.anonKey, {
      email: email,
      password: password
    }).then(function (data) {
      return self.storeSession(data);
    });
  };

  /* Zweitweg. Hinter Client-Zertifikaten unzuverlässig: der Rücksprung aus
     der Mail landet oft in einem Browser ohne Zertifikat. */
  SupabaseAdapter.prototype.sendMagicLink = function (email) {
    var redirect = window.location.origin + window.location.pathname;
    return authFetch(
      this.base,
      '/auth/v1/otp?redirect_to=' + encodeURIComponent(redirect),
      this.cfg.anonKey,
      { email: email, create_user: false }
    ).then(function () {
      return true;
    });
  };

  SupabaseAdapter.prototype.signOut = function () {
    var self = this;
    if (!this.session) return Promise.resolve();
    return fetch(this.base + '/auth/v1/logout', {
      method: 'POST',
      headers: this.headers()
    })
      .catch(function () {
        /* Auch wenn der Server nicht antwortet: lokal abmelden. */
      })
      .then(function () {
        self.clearSession();
      });
  };

  SupabaseAdapter.prototype.refresh = function () {
    var self = this;
    if (!this.session || !this.session.refresh_token) {
      return Promise.reject(new Error('Nicht angemeldet'));
    }
    /* Parallele Anfragen dürfen nicht jede für sich erneuern, sonst
       entwertet der zweite Aufruf das Token des ersten. */
    if (this.refreshing) return this.refreshing;

    this.refreshing = authFetch(
      this.base,
      '/auth/v1/token?grant_type=refresh_token',
      this.cfg.anonKey,
      { refresh_token: this.session.refresh_token }
    )
      .then(function (data) {
        self.refreshing = null;
        return self.storeSession(data);
      })
      .catch(function (err) {
        self.refreshing = null;
        self.clearSession();
        throw new Error('Sitzung abgelaufen, bitte neu anmelden');
      });

    return this.refreshing;
  };

  SupabaseAdapter.prototype.ensureToken = function () {
    if (this.cfg.mode !== 'auth') return Promise.resolve();
    if (!this.session) return Promise.reject(new Error('Nicht angemeldet'));
    /* Eine Minute Puffer, damit ein Token nicht mitten im Flug abläuft. */
    if (this.session.expires_at - 60 > Math.floor(Date.now() / 1000)) {
      return Promise.resolve();
    }
    return this.refresh().then(function () {});
  };

  SupabaseAdapter.prototype.request = function (url, options, retried) {
    var self = this;
    return this.ensureToken()
      .then(function () {
        return fetch(url, {
          method: options.method || 'GET',
          headers: self.headers(options.headers),
          body: options.body
        });
      })
      .then(function (res) {
        /* Abgelaufen oder zurückgezogen: einmal erneuern und wiederholen. */
        if (res.status === 401 && self.cfg.mode === 'auth' && !retried) {
          return self.refresh().then(function () {
            return self.request(url, options, true);
          });
        }
        return res;
      });
  };

  SupabaseAdapter.prototype.load = function () {
    return this.request(this.endpoint + '?select=*', {})
      .then(function (res) {
        if (!res.ok) throw new Error('Laden fehlgeschlagen (' + res.status + ')');
        return res.json();
      })
      .then(function (rows) {
        var all = {};
        rows.forEach(function (row) {
          all[row.key] = row;
        });
        return all;
      });
  };

  SupabaseAdapter.prototype.save = function (mark) {
    return this.request(this.endpoint + '?on_conflict=key', {
      method: 'POST',
      headers: { Prefer: 'resolution=merge-duplicates,return=minimal' },
      body: JSON.stringify(payload(mark))
    }).then(function (res) {
      if (!res.ok) throw new Error('Speichern fehlgeschlagen (' + res.status + ')');
    });
  };

  SupabaseAdapter.prototype.remove = function (key) {
    return this.request(this.endpoint + '?key=eq.' + encodeURIComponent(key), {
      method: 'DELETE',
      headers: { Prefer: 'return=minimal' }
    }).then(function (res) {
      if (!res.ok) throw new Error('Löschen fehlgeschlagen (' + res.status + ')');
    });
  };

  /* --- Store -------------------------------------------------------------- */

  function Store(config) {
    this.config = config;
    this.marks = {};
    this.listeners = [];
    this.status = { state: 'loading', adapter: 'local', message: 'Wird geladen' };

    var wantsSupabase =
      config.storage === 'supabase' &&
      config.supabase &&
      config.supabase.url &&
      config.supabase.anonKey;

    this.local = new LocalAdapter();
    this.remote = wantsSupabase ? new SupabaseAdapter(config.supabase) : null;
    this.adapter = this.remote || this.local;
  }

  Store.prototype.onChange = function (fn) {
    this.listeners.push(fn);
  };

  Store.prototype.emit = function () {
    var self = this;
    this.listeners.forEach(function (fn) {
      fn(self);
    });
  };

  Store.prototype.setStatus = function (state, message, action) {
    this.status = {
      state: state,
      adapter: this.adapter.name,
      message: message,
      /* 'login' oder 'logout', damit die Statusanzeige zum Knopf werden kann. */
      action: action || null
    };
    this.emit();
  };

  /* Ist Supabase eingerichtet, aber niemand angemeldet? */
  Store.prototype.needsLogin = function () {
    return !!this.remote && this.remote.needsLogin();
  };

  Store.prototype.isRemote = function () {
    return this.adapter.name === 'supabase';
  };

  Store.prototype.account = function () {
    return this.remote ? this.remote.accountLabel() : '';
  };

  Store.prototype.useLocal = function (reason) {
    var self = this;
    this.adapter = this.local;
    return this.local.load().then(function (all) {
      self.marks = all;
      if (reason) {
        self.setStatus('error', reason, self.needsLogin() ? 'login' : null);
      } else {
        self.setStatus('ok', 'Lokal gespeichert', self.remote ? 'login' : null);
      }
    });
  };

  Store.prototype.init = function () {
    var self = this;
    if (!this.remote) return this.useLocal();

    if (this.remote.needsLogin()) {
      return this.useLocal('Nicht angemeldet, lokal gespeichert');
    }
    return this.remote
      .load()
      .then(function (all) {
        self.adapter = self.remote;
        self.marks = all;
        self.setStatus('ok', 'Supabase' + accountSuffix(self), 'account');
      })
      .catch(function (err) {
        return self.useLocal(
          (err && err.message ? err.message : 'Backend nicht erreichbar') +
            ', lokal gespeichert'
        );
      });
  };

  function accountSuffix(store) {
    var email = store.account();
    return email ? ' · ' + email : '';
  }

  /* Nach der Anmeldung: Fernstand holen, lokal Angesammeltes einmischen und
     hochschieben. Ohne diesen Schritt wären Markierungen verloren, die vor
     der Anmeldung entstanden sind. */
  Store.prototype.useRemote = function () {
    var self = this;
    var localMarks = this.marks;

    return this.remote.load().then(function (remoteMarks) {
      var pending = [];
      Object.keys(localMarks).forEach(function (key) {
        var mine = localMarks[key];
        var theirs = remoteMarks[key];
        if (!theirs || (mine.updated_at || '') > (theirs.updated_at || '')) {
          remoteMarks[key] = mine;
          pending.push(mine);
        }
      });

      self.adapter = self.remote;
      self.marks = remoteMarks;
      self.emit();

      return Promise.all(
        pending.map(function (mark) {
          return self.remote.save(mark);
        })
      ).then(
        function () {
          self.setStatus('ok', 'Supabase' + accountSuffix(self), 'account');
          return pending.length;
        },
        function (err) {
          self.setStatus('error', 'Teilweise übertragen: ' + err.message, 'account');
          return pending.length;
        }
      );
    });
  };

  Store.prototype.signOut = function () {
    var self = this;
    if (!this.remote) return Promise.resolve();
    return this.remote.signOut().then(function () {
      return self.useLocal();
    });
  };

  Store.prototype.get = function (week, itemId) {
    return this.marks[markKey(week, itemId)] || emptyMark(week, itemId);
  };

  Store.prototype.isMarked = function (week, itemId) {
    var m = this.marks[markKey(week, itemId)];
    return !!(m && m.marked);
  };

  Store.prototype.isDone = function (week, itemId) {
    var m = this.marks[markKey(week, itemId)];
    return !!(m && m.done);
  };

  Store.prototype.note = function (week, itemId) {
    var m = this.marks[markKey(week, itemId)];
    return (m && m.note) || '';
  };

  Store.prototype.all = function () {
    var self = this;
    return Object.keys(this.marks)
      .map(function (k) {
        return self.marks[k];
      })
      .filter(function (m) {
        return m.marked || m.done || m.note;
      });
  };

  Store.prototype.countMarked = function () {
    return this.all().filter(function (m) {
      return m.marked && !m.done;
    }).length;
  };

  Store.prototype.update = function (week, itemId, patch) {
    var key = markKey(week, itemId);
    var next = Object.assign(emptyMark(week, itemId), this.marks[key] || {}, patch);
    next.updated_at = new Date().toISOString();

    var isEmpty = !next.marked && !next.done && !next.note;
    if (isEmpty) delete this.marks[key];
    else this.marks[key] = next;
    this.emit();

    var self = this;
    var op = isEmpty
      ? this.adapter.remove(key, this.marks)
      : this.adapter.save(next, this.marks);

    return Promise.resolve(op).catch(function (err) {
      /* Beim Backend schiefgegangen: lokal sichern, damit die Eingabe nicht
         nur im Arbeitsspeicher steht, und den Zustand offenlegen. */
      self.local.persist(self.marks);
      self.setStatus(
        'error',
        (err && err.message ? err.message : 'Speichern fehlgeschlagen'),
        self.needsLogin() ? 'login' : 'account'
      );
    });
  };

  Store.prototype.toggleMarked = function (week, itemId) {
    var now = !this.isMarked(week, itemId);
    this.update(week, itemId, { marked: now });
    return now;
  };

  Store.prototype.toggleDone = function (week, itemId) {
    var now = !this.isDone(week, itemId);
    /* Erledigt heißt gelesen und abgehakt. Die Markierung darf bleiben,
       damit nachvollziehbar ist, was man verfolgt hat. */
    this.update(week, itemId, { done: now });
    return now;
  };

  Store.prototype.setNote = function (week, itemId, note) {
    this.update(week, itemId, { note: note.trim() });
  };

  Store.prototype.exportJson = function () {
    return JSON.stringify(
      { schema: 1, exported_at: new Date().toISOString(), marks: this.all() },
      null,
      2
    );
  };

  Store.prototype.importJson = function (text) {
    var parsed = JSON.parse(text);
    var rows = Array.isArray(parsed) ? parsed : parsed.marks;
    if (!Array.isArray(rows)) throw new Error('Kein gültiger Export');

    var self = this;
    var changed = [];
    rows.forEach(function (row) {
      if (!row || !row.iso_week || !row.item_id) return;
      var key = markKey(row.iso_week, row.item_id);
      var existing = self.marks[key];
      /* Bei Konflikt gewinnt der neuere Zeitstempel. */
      if (existing && existing.updated_at >= (row.updated_at || '')) return;
      self.marks[key] = Object.assign(emptyMark(row.iso_week, row.item_id), row, {
        key: key
      });
      changed.push(self.marks[key]);
    });

    this.emit();
    return Promise.all(
      changed.map(function (mark) {
        return self.adapter.save(mark, self.marks);
      })
    ).then(function () {
      return changed.length;
    });
  };

  Store.prototype.clearAll = function () {
    var self = this;
    var keys = Object.keys(this.marks);
    this.marks = {};
    this.emit();
    if (this.adapter.name === 'local') return this.adapter.persist({});
    return Promise.all(
      keys.map(function (k) {
        return self.adapter.remove(k, self.marks);
      })
    );
  };

  window.KINEWS_Store = Store;
  window.KINEWS_markKey = markKey;
})();
