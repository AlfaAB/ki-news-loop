/* ---------------------------------------------------------------------------
   Setzt das gespeicherte Farbschema, bevor die Seite zum ersten Mal gezeichnet
   wird. Ohne diesen Schritt blitzt beim Laden kurz das helle Design auf,
   obwohl das dunkle gewählt ist.

   Bewusst eine eigene Datei statt eines Inline-Skripts: so kommt die
   Content-Security-Policy ohne 'unsafe-inline' bei script-src aus.
   Muss im <head> ohne defer oder async eingebunden sein.
   --------------------------------------------------------------------------- */

(function () {
  try {
    var theme = localStorage.getItem('kinews.theme');
    if (theme && theme !== 'system') {
      document.documentElement.setAttribute('data-theme', theme);
    }
  } catch (err) {
    /* Privater Modus oder blockierte Site-Daten: Systemeinstellung gilt. */
  }
})();
