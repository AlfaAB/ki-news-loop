/* ===========================================================================
   KI-News-Radar - Anwendung

   Hash-Routen:
     #/                    Diese Woche
     #/archiv              Archiv mit Suche und Filtern
     #/markiert            Merkliste
     #/woche/2026-W36      Einzelne Woche

   Rendering-Regel: Route- und Filterwechsel zeichnen die Liste neu, ein
   Klick auf "Merken" nicht. Der ändert nur die betroffene Karte. Sonst
   würde bei jedem Klick die Einblend-Animation neu starten und der Fokus
   springen.
   =========================================================================== */

(function () {
  'use strict';

  var UI = window.KINEWS_UI;
  var Claude = window.KINEWS_Claude;
  var CATEGORIES = window.KINEWS_CATEGORIES;
  var esc = UI.esc;
  var icon = UI.icon;

  var CAT_ICONS = {
    tools: 'wrench',
    studium: 'graduation-cap',
    alltag: 'house-line',
    quick: 'lightning',
    weitere: 'list-dashes'
  };

  /* Radar: jede Kategorie bekommt ein Drittel des Schirms, im Uhrzeigersinn
     ab zwölf Uhr. Das ist auch die Richtung, in die der Strahl läuft. */
  var SECTORS = { tools: 0, studium: 120, alltag: 240 };

  var NUMBER_WORDS = [
    'kein', 'ein', 'zwei', 'drei', 'vier', 'fünf', 'sechs',
    'sieben', 'acht', 'neun', 'zehn', 'elf', 'zwölf'
  ];

  var config = window.KINEWS_CONFIG;
  var data = new window.KINEWS_Data();
  var store = new window.KINEWS_Store(config);

  var state = {
    route: { name: 'home', param: null },
    routeKey: '',
    query: '',
    category: 'alle',
    year: 'alle',
    onlyMarked: false,
    onlyOpen: false,
    /* Steuert das Einblenden. Beim Tippen aus, sonst flackert die
       Trefferliste bei jedem Zeichen. */
    reveal: true
  };

  var els = {};
  var revealObserver = null;

  /* ======================================================================
     Hilfen
     ====================================================================== */

  function reduceMotion() {
    return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  }

  function capitalise(text) {
    return text.charAt(0).toUpperCase() + text.slice(1);
  }

  function countWord(n) {
    return n < NUMBER_WORDS.length ? NUMBER_WORDS[n] : String(n);
  }

  function pad2(n) {
    return n < 10 ? '0' + n : String(n);
  }

  /* Stabiler Wert zwischen 0 und 1 aus einem Text. Damit liegt ein Thema
     bei jedem Aufruf an derselben Stelle im Radar. */
  function hashUnit(text) {
    var h = 2166136261;
    for (var i = 0; i < text.length; i++) {
      h ^= text.charCodeAt(i);
      h = Math.imul(h, 16777619);
    }
    return (h >>> 0) / 4294967295;
  }

  function polar(angle, radius) {
    var rad = (angle * Math.PI) / 180;
    return {
      x: (50 + radius * 50 * Math.sin(rad)).toFixed(2),
      y: (50 - radius * 50 * Math.cos(rad)).toFixed(2)
    };
  }

  /* ======================================================================
     Route
     ====================================================================== */

  function parseRoute() {
    var hash = (window.location.hash || '#/').replace(/^#/, '');
    var parts = hash.split('/').filter(Boolean);
    if (!parts.length) return { name: 'home', param: null };
    if (parts[0] === 'archiv') return { name: 'archive', param: null };
    if (parts[0] === 'markiert') return { name: 'marked', param: null };
    if (parts[0] === 'woche' && parts[1]) {
      return { name: 'week', param: decodeURIComponent(parts[1]) };
    }
    return { name: 'home', param: null };
  }

  function go(hash) {
    if (window.location.hash === hash) render();
    else window.location.hash = hash;
  }

  /* ======================================================================
     Bausteine
     ====================================================================== */

  /* Das typografische Leitmotiv: ein Wort in Display-Serife über einem Wort
     in breiter, fetter Sans. Jede Ansicht hat genau eine solche Überschrift,
     damit es ein Motiv bleibt und nicht zur Masche wird. */
  function display(tag, serif, sans, opts) {
    opts = opts || {};
    var cls =
      'display display--' + (opts.size || 'page') +
      (opts.animate === false ? '' : ' display--animate');
    var scribble = opts.scribble
      ? '<svg class="scribble" viewBox="0 0 300 40" preserveAspectRatio="none" ' +
        'aria-hidden="true" focusable="false"><path pathLength="1" ' +
        'd="M5 27C62 15 142 9 212 14S292 27 295 21C247 31 164 35 92 35"/></svg>'
      : '';
    return (
      '<' + tag + ' class="' + cls + '"' + (opts.id ? ' id="' + opts.id + '"' : '') + '>' +
        '<span class="display__row"><span class="display__line">' +
          '<span class="display__word display__serif" style="--w:0">' + esc(serif) + '</span>' +
        '</span></span> ' +
        '<span class="display__row"><span class="display__line">' +
          '<span class="display__word display__sans" style="--w:1">' + esc(sans) + '</span>' +
        '</span>' + scribble + '</span>' +
      '</' + tag + '>'
    );
  }

  function sectionTitle(title, note) {
    return (
      '<div class="section-title">' +
        '<h2>' + esc(title) + '</h2>' +
        (note ? '<span class="section-title__note">' + esc(note) + '</span>' : '') +
      '</div>'
    );
  }

  function sourceLink(entry) {
    if (!entry.source.url) return '';
    var host = window.KINEWS_hostOf(entry.source.url);
    var name = entry.source.name || host;
    return (
      '<a class="source-link" href="' + esc(entry.source.url) + '" target="_blank" ' +
      'rel="noopener noreferrer">' +
        '<span class="source-link__icon">' + icon('arrow-up-right') + '</span>' +
        '<span>' + esc(name) + '</span>' +
        (entry.source.name && host && entry.source.name !== host
          ? '<span class="source-link__host">' + esc(host) + '</span>'
          : '') +
      '</a>'
    );
  }

  function markButtons(entry) {
    var marked = store.isMarked(entry.iso_week, entry.id);
    var done = store.isDone(entry.iso_week, entry.id);
    var markLabel = marked ? 'Markierung entfernen' : 'Thema merken';
    var doneLabel = done ? 'Wieder öffnen' : 'Als erledigt abhaken';
    return (
      '<button type="button" class="btn btn--icon btn--mark" data-action="mark" ' +
      'data-uid="' + esc(entry.uid) + '" aria-pressed="' + marked + '" ' +
      'title="' + markLabel + '" aria-label="' + markLabel + '">' +
        icon('bookmark-simple', marked) +
      '</button>' +
      '<button type="button" class="btn btn--icon btn--done" data-action="done" ' +
      'data-uid="' + esc(entry.uid) + '" aria-pressed="' + done + '" ' +
      'title="' + doneLabel + '" aria-label="' + doneLabel + '">' +
        icon(done ? 'check-circle' : 'circle', done) +
      '</button>'
    );
  }

  function actionButtons(entry) {
    return (
      '<button type="button" class="btn btn--sm btn--claude" data-action="claude" ' +
      'data-uid="' + esc(entry.uid) + '" aria-haspopup="menu" aria-expanded="false">' +
        icon('sparkle') + 'Mit Claude vertiefen' +
      '</button>' +
      '<button type="button" class="btn btn--ghost btn--sm" data-action="note" ' +
      'data-uid="' + esc(entry.uid) + '">' +
        icon('note-pencil') +
        (store.note(entry.iso_week, entry.id) ? 'Notiz bearbeiten' : 'Notiz') +
      '</button>'
    );
  }

  function noteBlock(entry) {
    var note = store.note(entry.iso_week, entry.id);
    if (!note) return '';
    return (
      '<div class="card__note"><b class="card__note-label">Deine Notiz</b>' +
      esc(note).replace(/\n/g, '<br>') +
      '</div>'
    );
  }

  function categoryTag(entry, large) {
    var cls = 'tag tag--cat' + (large ? ' tag--lg' : '');
    return (
      '<span class="' + cls + '">' +
        icon(CAT_ICONS[entry.category] || 'circle') +
        esc(CATEGORIES[entry.category] || entry.category) +
      '</span>'
    );
  }

  function tags(entry, opts) {
    opts = opts || {};
    var out = '';
    /* In der Wochenansicht steht die Kategorie groß neben der Rangzahl,
       dort wäre sie hier doppelt. */
    if (!opts.rank) {
      if (entry.kind === 'item') {
        out += categoryTag(entry);
      } else if (entry.kind === 'quick' && opts.showWeek) {
        out += '<span class="tag">' + icon('lightning') + 'Alltagshelfer</span>';
      } else if (entry.kind === 'archive') {
        out += '<span class="tag">Nur Titel</span>';
      }
    }
    if (entry.deadline) {
      out += '<span class="tag tag--deadline">' + icon('clock-countdown') +
        'Frist ' + esc(UI.formatDateShort(entry.deadline)) + '</span>';
    }
    if (opts.showWeek) {
      out += '<a class="tag tag--week" href="#/woche/' + esc(entry.iso_week) + '">KW ' +
        esc(entry.week) + '</a>';
    }
    if (entry.demo) {
      out += '<span class="tag tag--demo">Beispiel</span>';
    }
    return out;
  }

  function titleLink(entry, query) {
    var inner = UI.highlight(entry.title, query);
    return entry.source.url
      ? '<a href="' + esc(entry.source.url) + '" target="_blank" rel="noopener noreferrer">' +
        inner + '</a>'
      : inner;
  }

  function cardHtml(entry, index, opts) {
    opts = opts || {};
    var q = opts.query || '';
    var ranked = !!opts.rank;
    var slim = entry.kind === 'archive';
    var marked = store.isMarked(entry.iso_week, entry.id);
    var done = store.isDone(entry.iso_week, entry.id);
    var hasDetails = !!entry.relevance;

    var cls =
      'card' + (ranked ? ' card--ranked' : '') + (slim ? ' card--slim' : '') +
      (state.reveal ? ' reveal' : '');

    return (
      '<article class="' + cls + '" data-uid="' + esc(entry.uid) + '" tabindex="-1" ' +
      'data-marked="' + marked + '" data-done="' + done + '">' +
        (ranked
          ? '<div class="card__rank">' +
              '<span class="card__num" aria-hidden="true">' + pad2(opts.rank) + '</span>' +
              categoryTag(entry, true) +
            '</div>'
          : '') +
        '<div class="card__body">' +
          '<div class="card__top">' +
            '<div class="card__tag-row">' + tags(entry, opts) + '</div>' +
            '<div class="card__tools">' + markButtons(entry) + '</div>' +
          '</div>' +
          '<h3 class="card__title">' +
            (ranked ? '<span class="visually-hidden">Thema ' + opts.rank + ': </span>' : '') +
            titleLink(entry, q) +
          '</h3>' +
          (entry.summary
            ? '<p class="card__summary">' + UI.highlight(entry.summary, q) + '</p>'
            : '') +
          (hasDetails
            ? '<div class="card__details" data-open="false">' +
                '<div><div class="relevance">' +
                  '<div><b class="relevance__label">Fürs Studium</b>' +
                    '<p>' + UI.highlight(entry.relevance.studium, q) + '</p></div>' +
                  '<div><b class="relevance__label">Für den Alltag</b>' +
                    '<p>' + UI.highlight(entry.relevance.alltag, q) + '</p></div>' +
                '</div></div>' +
              '</div>'
            : '') +
          '<div class="card__note-slot">' + noteBlock(entry) + '</div>' +
          '<div class="card__foot">' +
            sourceLink(entry) +
            (hasDetails
              ? '<button type="button" class="btn btn--ghost btn--sm card__details-toggle" ' +
                'data-action="details" aria-expanded="false">' +
                'Einordnung' + icon('caret-down') + '</button>'
              : '') +
            '<span class="card__spacer"></span>' +
            actionButtons(entry) +
          '</div>' +
        '</div>' +
      '</article>'
    );
  }

  function quickHtml(entry, index, opts) {
    opts = opts || {};
    var q = opts.query || '';
    var marked = store.isMarked(entry.iso_week, entry.id);
    var done = store.isDone(entry.iso_week, entry.id);
    var tagRow = tags(entry, opts);
    var reveal = state.reveal && !opts.noReveal;

    return (
      '<article class="quick' + (reveal ? ' reveal' : '') + '" tabindex="-1" ' +
      'data-uid="' + esc(entry.uid) + '" data-marked="' + marked + '" data-done="' + done + '">' +
        '<div class="quick__head">' +
          (tagRow ? '<div class="card__tag-row">' + tagRow + '</div>' : '') +
          '<h3 class="quick__title">' + titleLink(entry, q) + '</h3>' +
        '</div>' +
        /* Quelle unter dem Text statt in der Aktionsspalte: so ist die
           Aktionsspalte in jeder Zeile gleich breit, und die Texte aller
           Zeilen beginnen auf derselben Linie. */
        '<div class="quick__main">' +
          (entry.summary
            ? '<p class="quick__summary">' + UI.highlight(entry.summary, q) + '</p>'
            : '') +
          sourceLink(entry) +
        '</div>' +
        '<div class="quick__actions">' +
          '<button type="button" class="btn btn--icon btn--claude" data-action="claude" ' +
          'data-uid="' + esc(entry.uid) + '" aria-haspopup="menu" aria-expanded="false" ' +
          'title="Mit Claude vertiefen" aria-label="Mit Claude vertiefen">' +
            icon('sparkle') +
          '</button>' +
          '<button type="button" class="btn btn--icon btn--ghost" data-action="note" ' +
          'data-uid="' + esc(entry.uid) + '" title="Notiz" aria-label="Notiz">' +
            icon('note-pencil') +
          '</button>' +
          '<div class="quick__tools">' + markButtons(entry) + '</div>' +
        '</div>' +
        '<div class="card__note-slot">' + noteBlock(entry) + '</div>' +
      '</article>'
    );
  }

  function demoBanner() {
    if (!data.demoActive) return '';
    return (
      '<div class="demo-banner">' + icon('flask') +
      '<span>Beispieldaten sind aktiv. Sie sind frei erfunden und dienen nur ' +
      'dazu, Archiv und Suche zu testen.</span>' +
      '<button type="button" class="btn btn--sm" data-action="demo-off">Entfernen</button>' +
      '</div>'
    );
  }

  /* Ohne Server kommen die Daten aus dem vorgebündelten Abzug. Der kann
     älter sein als data/weeks/, und das darf man nicht stillschweigend
     übergehen. */
  function offlineBanner() {
    if (!data.offline) return '';
    return (
      '<div class="demo-banner" data-variant="offline">' + icon('plugs') +
      '<span>Ohne Server geöffnet. Angezeigt wird der Abzug aus ' +
      '<code>data/bundle.js</code>, der älter sein kann als die Dateien unter ' +
      '<code>data/weeks/</code>. Für den aktuellen Stand <code>start.cmd</code> ' +
      'ausführen.</span>' +
      '</div>'
    );
  }

  /* GitHub war nicht erreichbar, die Daten kommen aus dem Ordner auf dem
     Server. Der ist nur so aktuell wie der letzte Upload, das soll man sehen. */
  function fallbackBanner() {
    if (!data.fallback || data.offline) return '';
    return (
      '<div class="demo-banner" data-variant="offline">' + icon('cloud-slash') +
      '<span>Die Wochendaten konnten gerade nicht von GitHub geladen werden. ' +
      'Angezeigt wird der Stand, der auf diesem Server liegt; die neueste ' +
      'Ausgabe fehlt dort eventuell noch.</span>' +
      '</div>'
    );
  }

  function banners() {
    return offlineBanner() + fallbackBanner() + demoBanner();
  }

  /* ======================================================================
     Radar und Laufschrift
     ====================================================================== */

  function blipHtml(entry, angle, radius, kind) {
    var p = polar(angle, radius);
    var label =
      (kind === 'item' ? (CATEGORIES[entry.category] || 'Thema') : 'Alltagshelfer') +
      ': ' + entry.title;
    return (
      /* Rechts der Mitte klappt das Etikett nach links. Sonst ragt es über
         den Rand und macht die Seite auf dem Handy seitlich verschiebbar,
         auch wenn es gerade unsichtbar ist. */
      '<button type="button" class="blip blip--' + kind +
      (Number(p.x) > 50 ? ' blip--left' : '') + '" ' +
      'style="--x:' + p.x + '%;--y:' + p.y + '%;--a:' + angle.toFixed(1) + '" ' +
      'data-action="scroll-to" data-target="' + esc(entry.uid) + '" ' +
      'data-marked="' + store.isMarked(entry.iso_week, entry.id) + '" ' +
      'aria-label="' + esc(label) + '">' +
        '<span class="blip__label" aria-hidden="true">' + esc(entry.title) + '</span>' +
      '</button>'
    );
  }

  function radarGrid() {
    var c = 200;
    var R = 196;
    var svg = '';
    [0.25, 0.5, 0.75, 1].forEach(function (f) {
      svg += '<circle cx="' + c + '" cy="' + c + '" r="' + (R * f).toFixed(1) + '"/>';
    });
    Object.keys(SECTORS).forEach(function (key) {
      var rad = (SECTORS[key] * Math.PI) / 180;
      svg += '<line class="radar__divider" x1="' + c + '" y1="' + c + '" ' +
        'x2="' + (c + R * Math.sin(rad)).toFixed(1) + '" ' +
        'y2="' + (c - R * Math.cos(rad)).toFixed(1) + '"/>';
    });
    for (var d = 0; d < 360; d += 6) {
      var rad = (d * Math.PI) / 180;
      var inner = d % 30 === 0 ? R - 11 : R - 5;
      svg += '<line class="radar__tick" ' +
        'x1="' + (c + R * Math.sin(rad)).toFixed(1) + '" y1="' + (c - R * Math.cos(rad)).toFixed(1) + '" ' +
        'x2="' + (c + inner * Math.sin(rad)).toFixed(1) + '" y2="' + (c - inner * Math.cos(rad)).toFixed(1) + '"/>';
    }
    return (
      '<svg class="radar__grid" viewBox="0 0 400 400" aria-hidden="true" focusable="false">' +
      svg + '</svg>'
    );
  }

  function weekMarkedCount(week) {
    return week.entries.filter(function (e) {
      return store.isMarked(e.iso_week, e.id);
    }).length;
  }

  function radarHtml(week, items, quick) {
    var blips = '';

    /* Hauptthemen im Sektor ihrer Kategorie, mit Abstand zu den Sektorgrenzen
       und zum Beschriftungsring. */
    items.forEach(function (entry, i) {
      var base = SECTORS[entry.category];
      if (base == null) base = (i * 120) % 360;
      var angle = base + 22 + hashUnit(entry.id) * 76;
      var radius = 0.28 + hashUnit(entry.id + ':r') * 0.28;
      blips += blipHtml(entry, angle, radius, 'item');
    });

    /* Alltagshelfer gehören zu keiner Kategorie und liegen deshalb gleichmäßig
       verteilt auf dem Außenring. */
    quick.forEach(function (entry, i) {
      var angle = ((i + 0.5) * (360 / quick.length) + 26) % 360;
      blips += blipHtml(entry, angle, 0.87, 'quick');
    });

    var sectors = Object.keys(SECTORS)
      .map(function (key) {
        var p = polar(SECTORS[key] + 60, 0.7);
        return '<span class="radar__sector" style="--x:' + p.x + '%;--y:' + p.y + '%">' +
          esc(CATEGORIES[key]) + '</span>';
      })
      .join('');

    var marked = weekMarkedCount(week);

    return (
      '<div class="radar-panel">' +
        '<div class="radar-panel__topo" aria-hidden="true"></div>' +
        '<div class="radar" role="group" aria-label="Radar mit den Themen der Woche, ' +
        'sortiert nach Kategorie">' +
          '<div class="radar__screen" aria-hidden="true"></div>' +
          radarGrid() +
          '<div class="radar__sweep" aria-hidden="true"></div>' +
          '<div aria-hidden="true">' + sectors + '</div>' +
          blips +
        '</div>' +
        '<div class="radar__legend">' +
          '<span><i class="lg" aria-hidden="true"></i>' + items.length +
            (items.length === 1 ? ' Thema' : ' Themen') + '</span>' +
          (quick.length
            ? '<span><i class="lg lg--quick" aria-hidden="true"></i>' + quick.length +
              ' Alltagshelfer</span>'
            : '') +
          '<span class="js-week-marked">' + marked + ' gemerkt</span>' +
        '</div>' +
      '</div>'
    );
  }

  /* Gegenläufige Laufschrift mit den Schlagzeilen der Woche. Rein
     dekorative Zusammenfassung dessen, was darunter ohnehin steht, deshalb
     für Screenreader ausgeblendet und nicht per Tab erreichbar. */
  function tickerHtml(items, quick) {
    function row(list, variant) {
      if (!list.length) return '';
      var unit = list
        .map(function (entry) {
          return (
            '<button type="button" class="ticker__item" tabindex="-1" data-action="scroll-to" ' +
            'data-target="' + esc(entry.uid) + '">' + esc(entry.title) +
            '<i class="ph-fill ph-asterisk ticker__sep" aria-hidden="true"></i></button>'
          );
        })
        .join('');
      /* Eine Hälfte muss breiter als der Bildschirm sein, sonst sieht man
         beim Umbruch eine Lücke. Kurze Listen werden deshalb wiederholt. */
      var half = '';
      var reps = list.length < 3 ? 3 : 2;
      for (var i = 0; i < reps; i++) half += unit;
      return (
        '<div class="ticker__row ticker__row--' + variant + '">' +
          '<div class="ticker__track">' + half + half + '</div>' +
        '</div>'
      );
    }
    return (
      '<div class="ticker" aria-hidden="true">' +
        row(items, 'sans') + row(quick, 'serif') +
      '</div>'
    );
  }

  /* Laufzeit aus der tatsächlichen Breite, damit beide Reihen unabhängig von
     der Textlänge gleich schnell wirken. */
  function tuneTicker() {
    els.content.querySelectorAll('.ticker__track').forEach(function (track) {
      var half = track.scrollWidth / 2;
      if (!half) return;
      var speed = track.parentNode.classList.contains('ticker__row--sans') ? 70 : 52;
      track.style.setProperty('--ticker-dur', Math.max(18, Math.round(half / speed)) + 's');
    });
  }

  /* ======================================================================
     Ansicht: Diese Woche / Einzelne Woche
     ====================================================================== */

  function quickBlock(quick) {
    return (
      '<section class="block reveal" aria-labelledby="quick-title">' +
        '<div class="block__topo" aria-hidden="true"></div>' +
        '<div class="block__head">' +
          display('h2', 'Kleine', 'Helfer', { size: 'section', animate: false, id: 'quick-title' }) +
          '<p class="block__sub">Werkzeuge und Alltagshelfer, die diese Woche ' +
          'aufgefallen sind.</p>' +
        '</div>' +
        '<div class="quick-list">' +
          quick.map(function (entry, i) {
            return quickHtml(entry, i, { noReveal: true });
          }).join('') +
        '</div>' +
      '</section>'
    );
  }

  function weekNav(nb) {
    return (
      '<nav class="week-nav" aria-label="Weitere Ausgaben">' +
        (nb.older
          ? '<a class="week-nav__link" href="#/woche/' + esc(nb.older.iso_week) + '">' +
            '<span class="week-nav__arrow">' + icon('arrow-left') + '</span>' +
            'KW ' + esc(nb.older.week) + '</a>'
          : '<span></span>') +
        '<a class="btn btn--ghost" href="#/archiv">Alle Wochen</a>' +
        (nb.newer
          ? '<a class="week-nav__link week-nav__link--next" href="#/woche/' +
            esc(nb.newer.iso_week) + '">KW ' + esc(nb.newer.week) +
            '<span class="week-nav__arrow">' + icon('arrow-right') + '</span></a>'
          : '<span></span>') +
      '</nav>'
    );
  }

  function renderWeekView(week, isLatest) {
    if (!week) {
      return (
        '<div class="view"><div class="container">' +
          '<header class="page-head">' + display('h1', 'Diese', 'Woche') + '</header>' +
          emptyState({
            icon: 'calendar-x',
            title: 'Noch keine Ausgabe',
            text: 'Sobald die Routine gelaufen ist, steht die Ausgabe hier.',
            actions: '<a class="btn" href="#/archiv">Zum Archiv</a>'
          }) +
        '</div></div>'
      );
    }

    var nb = data.neighbours(week.iso_week);
    var items = week.entries.filter(function (e) {
      return e.kind === 'item';
    });
    var quick = week.entries.filter(function (e) {
      return e.kind === 'quick';
    });
    var rest = week.entries.filter(function (e) {
      return e.kind === 'archive';
    });

    var lede =
      capitalise(countWord(items.length)) + (items.length === 1 ? ' Thema' : ' Themen') +
      (quick.length ? ', ' + countWord(quick.length) + ' Alltagshelfer' : '') + '. ';

    return (
      '<div class="view">' +
        '<div class="container">' +
          banners() +
          '<section class="hero" aria-labelledby="week-title">' +
            '<div class="hero__text">' +
              '<p class="meta">' +
                '<span class="marker">KW ' + esc(week.week) + ' / ' + esc(week.year) + '</span>' +
                '<span>' + esc(UI.formatDate(week.sent_date)) + '</span>' +
                '<span>' + esc(UI.relativeWeeks(week.sent_date)) + '</span>' +
              '</p>' +
              display(
                'h1',
                isLatest ? 'Diese' : 'Ausgabe',
                isLatest ? 'Woche' : 'KW ' + week.week,
                { size: 'hero', scribble: true, id: 'week-title' }
              ) +
              '<p class="hero__lede hero__fade">' + esc(lede) +
                (week.lead ? '<b>Aufmacher:</b> ' + esc(week.lead) : '') +
              '</p>' +
              '<div class="hero__cta hero__fade">' +
                (items.length
                  ? '<button type="button" class="btn btn--primary" data-action="scroll-to" ' +
                    'data-target="themen">Zu den Themen' + icon('arrow-down') + '</button>'
                  : '') +
                '<a class="btn" href="#/archiv">Archiv' + icon('arrow-right') + '</a>' +
              '</div>' +
            '</div>' +
            radarHtml(week, items, quick) +
          '</section>' +
        '</div>' +
        (items.length + quick.length ? tickerHtml(items, quick) : '') +
        '<div class="container">' +
          '<section class="stories" id="themen" tabindex="-1" aria-label="Themen der Woche">' +
            items.map(function (entry, i) {
              return cardHtml(entry, i, { rank: i + 1 });
            }).join('') +
          '</section>' +
          (quick.length ? quickBlock(quick) : '') +
          (rest.length
            ? sectionTitle('Ebenfalls verschickt', 'Nur Titel und Quelle') +
              '<div class="stream">' +
                rest.map(function (entry, i) {
                  return cardHtml(entry, i);
                }).join('') +
              '</div>'
            : '') +
          weekNav(nb) +
        '</div>' +
      '</div>'
    );
  }

  /* ======================================================================
     Ansicht: Archiv
     ====================================================================== */

  function matches(entry) {
    if (state.category !== 'alle' && entry.category !== state.category) return false;
    if (state.year !== 'alle' && String(entry.year) !== state.year) return false;
    if (state.onlyMarked && !store.isMarked(entry.iso_week, entry.id)) return false;
    if (state.onlyOpen && store.isDone(entry.iso_week, entry.id)) return false;
    if (state.query) {
      var terms = state.query.toLowerCase().split(/\s+/).filter(Boolean);
      for (var i = 0; i < terms.length; i++) {
        if (entry.haystack.indexOf(terms[i]) === -1) return false;
      }
    }
    return true;
  }

  function filtersActive() {
    return (
      !!state.query ||
      state.category !== 'alle' ||
      state.year !== 'alle' ||
      state.onlyMarked ||
      state.onlyOpen
    );
  }

  function filterBar() {
    var years = data.years();
    var counts = { alle: 0 };
    Object.keys(CATEGORIES).forEach(function (k) {
      counts[k] = 0;
    });
    data.entries.forEach(function (e) {
      counts.alle += 1;
      if (counts[e.category] != null) counts[e.category] += 1;
    });

    var chips = ['alle']
      .concat(Object.keys(CATEGORIES))
      .map(function (key) {
        var label = key === 'alle' ? 'Alle' : CATEGORIES[key];
        return (
          '<button type="button" class="chip" data-action="category" data-value="' + key + '" ' +
          'aria-pressed="' + (state.category === key) + '">' +
            (key === 'alle' ? '' : icon(CAT_ICONS[key] || 'circle')) + esc(label) +
            '<span class="chip__num">' + counts[key] + '</span>' +
          '</button>'
        );
      })
      .join('');

    return (
      '<div class="filters">' +
        '<label class="search">' + icon('magnifying-glass') +
          '<input type="search" id="search" placeholder="Themen, Quellen, Stichworte" ' +
          'value="' + esc(state.query) + '" autocomplete="off" spellcheck="false" ' +
          'aria-label="Archiv durchsuchen">' +
          '<kbd class="search__kbd" aria-hidden="true">/</kbd>' +
        '</label>' +
        '<div class="filters__row">' + chips +
          '<span class="filters__divider" aria-hidden="true"></span>' +
          '<button type="button" class="chip" data-action="only-marked" aria-pressed="' +
            state.onlyMarked + '">' + icon('bookmark-simple') + 'Nur markierte</button>' +
          '<button type="button" class="chip" data-action="only-open" aria-pressed="' +
            state.onlyOpen + '">' + icon('circle-dashed') + 'Nur offene</button>' +
          (years.length > 1
            ? '<select class="select-plain" data-action="year" aria-label="Jahr filtern">' +
              '<option value="alle"' + (state.year === 'alle' ? ' selected' : '') +
              '>Alle Jahre</option>' +
              years.map(function (y) {
                return '<option value="' + y + '"' +
                  (state.year === y ? ' selected' : '') + '>' + y + '</option>';
              }).join('') +
              '</select>'
            : '') +
          (filtersActive()
            ? '<button type="button" class="btn btn--ghost btn--sm" data-action="reset">' +
              icon('x') + 'Zurücksetzen</button>'
            : '') +
        '</div>' +
      '</div>'
    );
  }

  function weekRow(week) {
    var markedCount = weekMarkedCount(week);
    return (
      '<a class="week-row' + (state.reveal ? ' reveal' : '') + '" ' +
      'href="#/woche/' + esc(week.iso_week) + '">' +
        '<span class="week-row__num">' + esc(week.week) +
          '<small>KW / ' + esc(week.year) + '</small></span>' +
        '<span class="week-row__body">' +
          '<span class="week-row__lead">' + esc(week.lead || 'Ausgabe KW ' + week.week) +
          '</span>' +
          '<span class="week-row__meta">' +
            '<span>' + esc(UI.formatDate(week.sent_date)) + '</span>' +
            '<span>' + week.entries.length + ' Themen</span>' +
            (markedCount
              ? '<span class="week-row__marked">' + icon('bookmark-simple', true) +
                markedCount + ' markiert</span>'
              : '') +
            (week.demo ? '<span class="tag tag--demo">Beispiel</span>' : '') +
          '</span>' +
        '</span>' +
        '<span class="week-row__go" aria-hidden="true">' + icon('arrow-right') + '</span>' +
      '</a>'
    );
  }

  function renderArchive() {
    var html =
      '<div class="view"><div class="container">' +
      banners() +
      '<header class="page-head">' +
        display('h1', 'Das', 'Archiv') +
        '<p class="page-head__lede">' + data.entries.length + ' Themen aus ' +
        data.weeks.length + (data.weeks.length === 1 ? ' Woche' : ' Wochen') +
        '. Die Suche durchsucht Titel, Zusammenfassung, Einordnung, Stichworte und ' +
        'Quelle.</p>' +
        /* Solange erst wenige echte Wochen da sind, ist der Weg zu den
           Beispieldaten sonst nur über den Leerzustand erreichbar. */
        (window.KINEWS_DEMO && !data.demoActive
          ? '<div class="page-head__actions">' +
            '<button type="button" class="btn btn--ghost btn--sm" data-action="demo-on">' +
            icon('flask') + 'Beispieldaten laden</button></div>'
          : '') +
      '</header>' +
      filterBar();

    if (!data.entries.length) {
      return html + noDataState() + '</div></div>';
    }

    if (!filtersActive()) {
      /* Ohne aktiven Filter ist die Wochenliste die bessere Übersicht als
         eine flache Liste aller Themen. */
      return (
        html + '<div class="week-list">' + data.weeks.map(weekRow).join('') + '</div>' +
        '</div></div>'
      );
    }

    var hits = data.entries.filter(matches);
    html +=
      '<p class="result-note"><strong>' + hits.length + '</strong> Treffer' +
      (state.query ? ' für „' + esc(state.query) + '“' : '') + '</p>';

    if (!hits.length) {
      return (
        html +
        emptyState({
          icon: 'magnifying-glass',
          title: 'Nichts gefunden',
          text: 'Kein Thema passt auf diese Kombination aus Suche und Filtern.',
          actions: '<button type="button" class="btn" data-action="reset">Filter zurücksetzen</button>'
        }) +
        '</div></div>'
      );
    }

    return (
      html + '<div class="stream">' +
        hits.map(function (entry, i) {
          var opts = { query: state.query, showWeek: true };
          return entry.kind === 'quick' ? quickHtml(entry, i, opts) : cardHtml(entry, i, opts);
        }).join('') +
      '</div></div></div>'
    );
  }

  /* ======================================================================
     Ansicht: Merkliste
     ====================================================================== */

  function renderMarked() {
    var entries = store
      .all()
      .map(function (m) {
        return data.entry(m.iso_week + '::' + m.item_id);
      })
      .filter(Boolean);

    var open = entries.filter(function (e) {
      return !store.isDone(e.iso_week, e.id);
    });
    var done = entries.filter(function (e) {
      return store.isDone(e.iso_week, e.id);
    });

    function list(group) {
      return (
        '<div class="stream">' +
          group.map(function (entry, i) {
            return entry.kind === 'quick'
              ? quickHtml(entry, i, { showWeek: true })
              : cardHtml(entry, i, { showWeek: true });
          }).join('') +
        '</div>'
      );
    }

    var html =
      '<div class="view"><div class="container">' +
      banners() +
      '<header class="page-head">' +
        display('h1', 'Deine', 'Merkliste') +
        '<p class="page-head__lede">Themen, die du markiert, kommentiert oder abgehakt ' +
        'hast. Sie liegen ' +
        (store.status.adapter === 'supabase' ? 'in deiner Supabase-Tabelle' : 'in diesem Browser') +
        '.</p>' +
        '<div class="page-head__actions">' +
          '<button type="button" class="btn btn--sm" data-action="export">' +
            icon('download-simple') + 'Exportieren</button>' +
          '<button type="button" class="btn btn--sm" data-action="import">' +
            icon('upload-simple') + 'Importieren</button>' +
          (entries.length
            ? '<button type="button" class="btn btn--ghost btn--sm" data-action="clear">' +
              icon('trash') + 'Alles löschen</button>'
            : '') +
        '</div>' +
      '</header>';

    if (!entries.length) {
      return (
        html +
        emptyState({
          icon: 'bookmark-simple',
          title: 'Noch nichts gemerkt',
          text: 'Tippe bei einem Thema auf das Lesezeichen, um es hier festzuhalten. ' +
            'Notizen und der Erledigt-Status landen ebenfalls hier.',
          actions: '<a class="btn btn--primary" href="#/">Zur aktuellen Woche</a>' +
            '<a class="btn" href="#/archiv">Archiv durchsuchen</a>'
        }) +
        '</div></div>'
      );
    }

    if (open.length) {
      html += sectionTitle('Offen', open.length + (open.length === 1 ? ' Thema' : ' Themen')) +
        list(open);
    }
    if (done.length) {
      html += sectionTitle('Erledigt', done.length + (done.length === 1 ? ' Thema' : ' Themen')) +
        list(done);
    }
    return html + '</div></div>';
  }

  /* ======================================================================
     Leer- und Fehlerzustände
     ====================================================================== */

  function emptyState(opts) {
    return (
      '<div class="empty' + (opts.error ? ' empty--error' : '') + '">' +
      '<i class="ph ph-' + opts.icon + ' empty__icon" aria-hidden="true"></i>' +
      '<h3>' + esc(opts.title) + '</h3>' +
      '<p>' + (opts.html || esc(opts.text)) + '</p>' +
      (opts.actions ? '<div class="empty__actions">' + opts.actions + '</div>' : '') +
      '</div>'
    );
  }

  function noDataState() {
    return emptyState({
      icon: 'database',
      title: 'Keine Wochendaten',
      text: 'Unter data/weeks/ liegt noch keine gültige JSON-Datei.',
      actions: window.KINEWS_DEMO
        ? '<button type="button" class="btn btn--primary" data-action="demo-on">' +
          'Beispieldaten laden</button>'
        : ''
    });
  }

  function loadErrorState(err) {
    return (
      '<div class="view"><div class="container">' +
      '<header class="page-head">' + display('h1', 'Daten', 'fehlen') + '</header>' +
      emptyState({
        error: true,
        icon: 'plugs',
        title: 'Wochendaten nicht lesbar',
        html:
          'Wenn du die Seite per Doppelklick geöffnet hast, blockiert der Browser ' +
          'das Lesen lokaler Dateien. Starte den mitgelieferten Server:' +
          '<br><span class="code-line">start.cmd' +
          '<button type="button" class="btn btn--ghost btn--sm" data-action="copy-cmd">' +
          icon('copy') + 'Kopieren</button></span>' +
          '<br><small style="color:var(--subtle)">' +
          esc(String((err && err.message) || err)) + '</small>',
        actions: '<button type="button" class="btn" data-action="reload">Neu laden</button>' +
          (window.KINEWS_DEMO
            ? '<button type="button" class="btn btn--primary" data-action="demo-on">' +
              'Beispieldaten laden</button>'
            : '')
      }) +
      '</div></div>'
    );
  }

  /* ======================================================================
     Rendern
     ====================================================================== */

  function observeReveals() {
    var nodes = els.content.querySelectorAll('.reveal:not(.is-in)');
    if (!nodes.length) return;
    if (!('IntersectionObserver' in window)) {
      nodes.forEach(function (n) {
        n.classList.add('is-in');
      });
      return;
    }
    if (!revealObserver) {
      revealObserver = new IntersectionObserver(
        function (entries) {
          /* Was im selben Moment sichtbar wird, kommt leicht gestaffelt. */
          entries
            .filter(function (e) {
              return e.isIntersecting;
            })
            .forEach(function (e, i) {
              e.target.style.setProperty('--d', i * 70 + 'ms');
              e.target.classList.add('is-in');
              revealObserver.unobserve(e.target);
            });
        },
        { rootMargin: '0px 0px -8% 0px', threshold: 0.06 }
      );
    }
    nodes.forEach(function (n) {
      revealObserver.observe(n);
    });
  }

  function afterRender() {
    observeReveals();
    tuneTicker();
  }

  function render() {
    state.route = parseRoute();
    var route = state.route;
    var key = route.name + ':' + (route.param || '');
    var routeChanged = key !== state.routeKey;
    state.routeKey = key;

    if (revealObserver) revealObserver.disconnect();

    var html;
    var title;

    if (route.name === 'archive') {
      html = renderArchive();
      title = 'Archiv';
    } else if (route.name === 'marked') {
      html = renderMarked();
      title = 'Merkliste';
    } else if (route.name === 'week') {
      var week = data.week(route.param);
      html = renderWeekView(week, !!data.latest() && data.latest().iso_week === route.param);
      title = week ? 'KW ' + week.week + ' / ' + week.year : 'Woche';
    } else {
      html = data.weeks.length
        ? renderWeekView(data.latest(), true)
        : '<div class="view"><div class="container"><header class="page-head">' +
          display('h1', 'Noch', 'leer') + '</header>' + noDataState() + '</div></div>';
      title = 'Diese Woche';
    }

    els.content.innerHTML = html;
    document.title = title + ' · ' + config.siteName;

    /* Neue Ansicht beginnt oben. Filter, Anmeldung und Ähnliches zeichnen
       dieselbe Route neu und behalten die Position. */
    if (routeChanged) window.scrollTo(0, 0);

    updateNav();
    updateFooter();
    afterRender();
    /* Nach dem ersten Zeichnen einer Ansicht darf das Einblenden wieder
       greifen, bis das nächste Tippen es abschaltet. */
    state.reveal = true;

    var search = document.getElementById('search');
    if (search && state.query) {
      search.focus();
      search.setSelectionRange(search.value.length, search.value.length);
    }
  }

  /* Nur die Liste neu zeichnen, ohne Einblenden. Für Suche und Filter. */
  function rerenderQuiet() {
    state.reveal = false;
    var scroll = window.scrollY;
    var search = document.getElementById('search');
    var caret = search ? search.selectionStart : null;

    if (revealObserver) revealObserver.disconnect();
    els.content.innerHTML = renderArchive();

    var next = document.getElementById('search');
    if (next && search) {
      next.focus();
      if (caret != null) next.setSelectionRange(caret, caret);
    }
    window.scrollTo(0, scroll);
    updateNav();
  }

  function updateNav() {
    var route = state.route.name;
    document.querySelectorAll('[data-nav]').forEach(function (link) {
      var key = link.dataset.nav;
      if (key === route || (key === 'home' && route === 'week')) {
        link.setAttribute('aria-current', 'page');
      } else {
        link.removeAttribute('aria-current');
      }
    });
    var count = store.countMarked();
    document.querySelectorAll('.js-marked-count').forEach(function (el) {
      el.textContent = count;
      el.hidden = count === 0;
    });
  }

  function updateFooter() {
    if (!els.footerMeta) return;
    var latest = data.latest();
    els.footerMeta.textContent = latest
      ? 'Letzte Ausgabe: KW ' + latest.week + ', ' + UI.formatDate(latest.sent_date)
      : 'Noch keine Ausgabe geladen';
  }

  function updateStatus() {
    var s = store.status;
    els.status.dataset.state = s.state;

    if (s.action) els.status.dataset.action = s.action;
    else els.status.removeAttribute('data-action');
    els.status.disabled = !s.action;

    var leading =
      s.state === 'error'
        ? 'warning-circle'
        : s.adapter === 'supabase'
        ? 'cloud-check'
        : 'hard-drives';
    var trailing =
      s.action === 'login' ? 'sign-in' : s.action === 'account' ? 'caret-up-down' : '';

    els.status.innerHTML =
      icon(leading) + '<span>' + esc(s.message) + '</span>' +
      (trailing
        ? '<i class="ph ph-' + trailing + ' storage-status__chev" aria-hidden="true"></i>'
        : '');
    els.status.title = s.action === 'login' ? s.message + '. Zum Anmelden klicken.' : s.message;
    els.status.setAttribute('aria-label', els.status.title);
  }

  /* Legende und Radarpunkte der aktuellen Woche nachziehen, wenn sich eine
     Markierung ändert. */
  function syncWeekMarks() {
    var legend = els.content.querySelector('.js-week-marked');
    if (!legend) return;
    var week =
      state.route.name === 'week' ? data.week(state.route.param) : data.latest();
    if (!week) return;
    legend.textContent = weekMarkedCount(week) + ' gemerkt';
    els.content.querySelectorAll('.blip').forEach(function (blip) {
      var entry = data.entry(blip.dataset.target);
      if (entry) blip.dataset.marked = store.isMarked(entry.iso_week, entry.id);
    });
  }

  /* Karte nach einer Zustandsänderung punktuell aktualisieren, statt die
     ganze Ansicht neu zu zeichnen. */
  function refreshCard(uid) {
    var entry = data.entry(uid);
    if (!entry) return;
    var nodes = els.content.querySelectorAll('[data-uid="' + CSS.escape(uid) + '"]');
    nodes.forEach(function (node) {
      if (!node.classList.contains('card') && !node.classList.contains('quick')) return;
      node.dataset.marked = store.isMarked(entry.iso_week, entry.id);
      node.dataset.done = store.isDone(entry.iso_week, entry.id);

      var tools = node.querySelector('.card__tools, .quick__tools');
      if (tools) tools.innerHTML = markButtons(entry);

      var slot = node.querySelector('.card__note-slot');
      if (slot) slot.innerHTML = noteBlock(entry);

      var noteBtn = node.querySelector('[data-action="note"]');
      if (noteBtn && noteBtn.classList.contains('btn--sm')) {
        noteBtn.innerHTML = icon('note-pencil') +
          (store.note(entry.iso_week, entry.id) ? 'Notiz bearbeiten' : 'Notiz');
      }
    });
    syncWeekMarks();
    updateNav();
  }

  /* Sprung aus Radar, Laufschrift oder Hero zu einem Thema. Der Fokus wandert
     mit, damit Tastaturnutzer dort weiterlesen, wo sie hingesprungen sind. */
  function scrollToTarget(target) {
    var node =
      target === 'themen'
        ? document.getElementById('themen')
        : els.content.querySelector(
            '.card[data-uid="' + CSS.escape(target) + '"], ' +
            '.quick[data-uid="' + CSS.escape(target) + '"]'
          );
    if (!node) return;

    node.classList.add('is-in');
    var block = node.closest('.block');
    if (block) block.classList.add('is-in');

    node.scrollIntoView({ behavior: reduceMotion() ? 'auto' : 'smooth', block: 'start' });
    node.focus({ preventScroll: true });

    if (node.classList.contains('card') || node.classList.contains('quick')) {
      node.classList.remove('is-flash');
      void node.offsetWidth;
      node.classList.add('is-flash');
      setTimeout(function () {
        node.classList.remove('is-flash');
      }, 1500);
    }
  }

  /* ======================================================================
     Aktionen
     ====================================================================== */

  function openClaudeMenu(button, entry) {
    var items = Claude.templates()
      .map(function (t) {
        return (
          '<button type="button" class="popover__item" data-value="' + esc(t.id) + '" ' +
          'role="menuitem"><b>' + esc(t.label) + '</b><span>' + esc(t.hint) + '</span></button>'
        );
      })
      .join('');

    UI.showPopover(
      button,
      '<div class="popover__head">Recherche starten</div>' + items +
      '<div class="popover__sep"></div>' +
      '<button type="button" class="popover__item" data-value="__copy" role="menuitem">' +
      '<b>Prompt kopieren</b><span>Statt Claude zu öffnen</span></button>',
      function (value) {
        if (value === '__copy') {
          var text = Claude.buildPrompt(Claude.templates()[0].text, entry);
          UI.copyText(text).then(
            function () {
              UI.toast('Prompt kopiert', 'copy');
            },
            function () {
              UI.toast('Kopieren nicht möglich', 'warning-circle');
            }
          );
          return;
        }
        var template = Claude.templateById(value);
        if (!template) return;
        window.open(Claude.url(Claude.buildPrompt(template.text, entry)), '_blank', 'noopener');
      }
    );
  }

  function openNoteDialog(entry) {
    var current = store.note(entry.iso_week, entry.id);
    UI.dialog({
      title: 'Notiz',
      description: entry.title,
      body:
        '<textarea name="note" data-autofocus placeholder="Warum ist das für dich relevant? ' +
        'Was willst du damit noch machen?">' + esc(current) + '</textarea>',
      footer:
        (current
          ? '<button class="btn btn--ghost" value="delete">Notiz löschen</button>'
          : '<span></span>') +
        '<button class="btn" value="cancel">Abbrechen</button>' +
        '<button class="btn btn--primary" value="save">Speichern</button>',
      onClose: function (value, node) {
        if (value === 'save') {
          store.setNote(entry.iso_week, entry.id, node.querySelector('textarea').value);
          UI.toast('Notiz gespeichert', 'note-pencil');
          refreshCard(entry.uid);
        } else if (value === 'delete') {
          store.setNote(entry.iso_week, entry.id, '');
          UI.toast('Notiz gelöscht', 'trash');
          refreshCard(entry.uid);
        }
      }
    });
  }

  /* ----------------------------------------------------------------------
     Anmeldung
     ---------------------------------------------------------------------- */

  function lastEmail() {
    try {
      return localStorage.getItem('kinews.lastEmail') || '';
    } catch (err) {
      return '';
    }
  }

  function rememberEmail(email) {
    try {
      localStorage.setItem('kinews.lastEmail', email);
    } catch (err) {
      /* Ohne Speicher muss die Adresse jedes Mal neu eingetippt werden. */
    }
  }

  function openLoginDialog() {
    return UI.dialog({
      title: 'Bei Supabase anmelden',
      description:
        'Danach werden Markierungen, Notizen und Erledigt-Status zwischen ' +
        'deinen Geräten abgeglichen.',
      body:
        '<div class="form-row"><label for="login-email">E-Mail</label>' +
        '<input id="login-email" type="email" data-autofocus autocomplete="username" ' +
        'value="' + esc(lastEmail()) + '" placeholder="du@beispiel.de"></div>' +
        '<div class="form-row"><label for="login-password">Passwort</label>' +
        '<input id="login-password" type="password" autocomplete="current-password"></div>' +
        '<p class="form-error" hidden></p>' +
        '<p class="form-hint">Das Konto legst du einmalig im Supabase-Dashboard an: ' +
        'Authentication, Users, Add user. Die Website selbst legt keine Konten an.</p>',
      footer:
        '<button class="btn btn--ghost" type="button" data-login="magic">Magic Link</button>' +
        '<button class="btn" value="cancel">Abbrechen</button>' +
        '<button class="btn btn--primary" type="button" data-login="password">Anmelden</button>',
      onReady: function (dlg) {
        var email = dlg.querySelector('#login-email');
        var password = dlg.querySelector('#login-password');

        function fail(message) {
          UI.dialogError(dlg, message);
        }

        function run(button, label, work) {
          if (!email.value.trim()) {
            fail('Bitte eine E-Mail-Adresse eintragen.');
            email.focus();
            return;
          }
          UI.dialogError(dlg, '');
          UI.setBusy(button, true, label);
          work(email.value.trim()).then(
            function () {
              UI.setBusy(button, false);
            },
            function (err) {
              UI.setBusy(button, false);
              fail(err && err.message ? err.message : 'Fehlgeschlagen');
            }
          );
        }

        dlg.querySelector('[data-login="password"]').addEventListener('click', function () {
          var button = this;
          if (!password.value) {
            fail('Bitte das Passwort eintragen.');
            password.focus();
            return;
          }
          run(button, 'Melde an…', function (mail) {
            return store.remote.signInWithPassword(mail, password.value).then(function () {
              rememberEmail(mail);
              /* Erst nach erfolgreicher Anmeldung schließen, damit ein
                 falsches Passwort nicht die Eingabe wegwirft. */
              dlg.close('done');
              return store.useRemote().then(function (pushed) {
                UI.toast(
                  pushed ? 'Angemeldet, ' + pushed + ' lokale Einträge übertragen' : 'Angemeldet',
                  'cloud-check'
                );
                render();
              });
            });
          });
        });

        dlg.querySelector('[data-login="magic"]').addEventListener('click', function () {
          var button = this;
          run(button, 'Sende…', function (mail) {
            return store.remote.sendMagicLink(mail).then(function () {
              rememberEmail(mail);
              dlg.close('done');
              UI.toast('Magic Link verschickt, sieh in dein Postfach', 'envelope-simple');
            });
          });
        });
      }
    });
  }

  function openAccountMenu(button) {
    var email = store.account();
    UI.showPopover(
      button,
      '<div class="popover__head">' + esc(email || 'Supabase') + '</div>' +
        '<button type="button" class="popover__item" data-value="reload" role="menuitem">' +
        '<b>Neu laden</b><span>Stand vom Server holen</span></button>' +
        '<div class="popover__sep"></div>' +
        '<button type="button" class="popover__item" data-value="signout" role="menuitem">' +
        '<b>Abmelden</b><span>Danach wieder lokal gespeichert</span></button>',
      function (value) {
        if (value === 'reload') {
          store.init().then(function () {
            UI.toast('Aktualisiert', 'arrows-clockwise');
            render();
          });
        } else if (value === 'signout') {
          store.signOut().then(function () {
            UI.toast('Abgemeldet, wieder lokal gespeichert', 'sign-out');
            render();
          });
        }
      }
    );
  }

  function openShortcuts() {
    var rows = [
      ['/', 'Suche im Archiv fokussieren'],
      ['g dann h', 'Diese Woche'],
      ['g dann a', 'Archiv'],
      ['g dann m', 'Merkliste'],
      ['t', 'Hell / dunkel umschalten'],
      ['Esc', 'Menü oder Dialog schließen'],
      ['?', 'Diese Übersicht']
    ];
    UI.dialog({
      title: 'Tastenkürzel',
      body: rows
        .map(function (r) {
          return '<div class="shortcut-row"><kbd>' + esc(r[0]) + '</kbd>' +
            '<span>' + esc(r[1]) + '</span></div>';
        })
        .join(''),
      footer: '<span></span><button class="btn btn--primary" value="ok">Schließen</button>'
    });
  }

  function doExport() {
    var text = store.exportJson();
    UI.copyText(text).then(
      function () {
        UI.toast('Markierungen in die Zwischenablage kopiert', 'copy');
      },
      function () {
        UI.dialog({
          title: 'Export',
          description: 'Kopieren war nicht möglich. Hier ist der Inhalt zum Herauskopieren.',
          body: '<textarea data-autofocus readonly>' + esc(text) + '</textarea>',
          footer: '<span></span><button class="btn btn--primary" value="ok">Fertig</button>'
        });
      }
    );
  }

  function doImport() {
    UI.dialog({
      title: 'Markierungen importieren',
      description: 'Füge hier einen zuvor exportierten JSON-Text ein. Bei Konflikten ' +
        'gewinnt der neuere Eintrag.',
      body: '<textarea data-autofocus placeholder=\'{ "marks": [ ... ] }\'></textarea>',
      footer:
        '<span></span><button class="btn" value="cancel">Abbrechen</button>' +
        '<button class="btn btn--primary" value="ok">Importieren</button>',
      onClose: function (value, node) {
        if (value !== 'ok') return;
        try {
          store.importJson(node.querySelector('textarea').value).then(function (n) {
            UI.toast(n + ' Einträge übernommen', 'check-circle');
            render();
          });
        } catch (err) {
          UI.toast('Kein gültiger Export', 'warning-circle');
        }
      }
    });
  }

  function doClear() {
    UI.dialog({
      title: 'Alle Markierungen löschen?',
      description: 'Markierungen, Notizen und Erledigt-Status werden entfernt. ' +
        'Das lässt sich nicht rückgängig machen.',
      body: '<p style="color:var(--muted);font-size:14px">Exportiere vorher, ' +
        'wenn du sie behalten willst.</p>',
      footer:
        '<span></span><button class="btn" value="cancel" data-autofocus>Abbrechen</button>' +
        '<button class="btn btn--primary" value="ok">Löschen</button>',
      onClose: function (value) {
        if (value !== 'ok') return;
        store.clearAll().then(function () {
          UI.toast('Alles gelöscht', 'trash');
          render();
        });
      }
    });
  }

  /* ======================================================================
     Ereignisse
     ====================================================================== */

  function onClick(event) {
    var trigger = event.target.closest('[data-action]');
    if (!trigger) return;
    var action = trigger.dataset.action;
    var uid = trigger.dataset.uid;
    var entry = uid ? data.entry(uid) : null;

    switch (action) {
      case 'mark':
        event.preventDefault();
        var nowMarked = store.toggleMarked(entry.iso_week, entry.id);
        refreshCard(uid);
        /* Der frisch gezeichnete Knopf ist ein anderes Element. */
        var freshMark = els.content.querySelector(
          '[data-uid="' + CSS.escape(uid) + '"] [data-action="mark"]'
        );
        if (freshMark) UI.pressPop(freshMark);
        UI.toast(nowMarked ? 'Gemerkt' : 'Markierung entfernt',
          nowMarked ? 'bookmark-simple' : 'bookmark-simple-slash');
        break;

      case 'done':
        event.preventDefault();
        var nowDone = store.toggleDone(entry.iso_week, entry.id);
        refreshCard(uid);
        var freshDone = els.content.querySelector(
          '[data-uid="' + CSS.escape(uid) + '"] [data-action="done"]'
        );
        if (freshDone) UI.pressPop(freshDone);
        UI.toast(nowDone ? 'Als erledigt abgehakt' : 'Wieder offen',
          nowDone ? 'check-circle' : 'circle');
        break;

      case 'details':
        event.preventDefault();
        var details = trigger.closest('.card').querySelector('.card__details');
        var open = details.dataset.open !== 'true';
        details.dataset.open = open;
        trigger.setAttribute('aria-expanded', open);
        break;

      case 'claude':
        event.preventDefault();
        event.stopPropagation();
        openClaudeMenu(trigger, entry);
        break;

      case 'note':
        event.preventDefault();
        openNoteDialog(entry);
        break;

      case 'scroll-to':
        event.preventDefault();
        scrollToTarget(trigger.dataset.target);
        break;

      case 'category':
        state.category = trigger.dataset.value;
        rerenderQuiet();
        break;

      case 'only-marked':
        state.onlyMarked = !state.onlyMarked;
        rerenderQuiet();
        break;

      case 'only-open':
        state.onlyOpen = !state.onlyOpen;
        rerenderQuiet();
        break;

      case 'reset':
        state.query = '';
        state.category = 'alle';
        state.year = 'alle';
        state.onlyMarked = false;
        state.onlyOpen = false;
        render();
        break;

      case 'theme':
        toggleTheme();
        break;

      case 'shortcuts':
        openShortcuts();
        break;

      case 'login':
        event.preventDefault();
        openLoginDialog();
        break;

      case 'account':
        event.preventDefault();
        event.stopPropagation();
        openAccountMenu(trigger);
        break;

      case 'export':
        doExport();
        break;

      case 'import':
        doImport();
        break;

      case 'clear':
        doClear();
        break;

      case 'demo-on':
        data.enableDemo();
        UI.toast('Beispieldaten geladen', 'flask');
        render();
        break;

      case 'demo-off':
        data.disableDemo();
        break;

      case 'reload':
        window.location.reload();
        break;

      case 'copy-cmd':
        UI.copyText('start.cmd').then(function () {
          UI.toast('Befehl kopiert', 'copy');
        });
        break;
    }
  }

  function onInput(event) {
    if (event.target.id === 'search') {
      state.query = event.target.value.trim();
      rerenderQuiet();
    }
  }

  function onChange(event) {
    if (event.target.dataset.action === 'year') {
      state.year = event.target.value;
      rerenderQuiet();
    }
  }

  var pendingG = false;

  function onKeydown(event) {
    var tag = (event.target.tagName || '').toLowerCase();
    var typing = tag === 'input' || tag === 'textarea' || tag === 'select';

    if (event.key === 'Escape' && typing && event.target.id === 'search') {
      state.query = '';
      rerenderQuiet();
      return;
    }

    /* Ein offener Dialog schließt normalerweise von selbst auf Escape. In
       eingebetteten Ansichten und älteren Engines passiert das nicht immer,
       deshalb hier explizit. Läuft vor der Tipp-Sperre, damit es auch aus
       dem Notizfeld heraus greift. */
    if (event.key === 'Escape') {
      var openDialog = document.querySelector('dialog[open]');
      if (openDialog) {
        openDialog.close('cancel');
        return;
      }
    }

    if (typing || event.metaKey || event.ctrlKey || event.altKey) return;

    if (event.key === '/') {
      event.preventDefault();
      if (state.route.name !== 'archive') {
        go('#/archiv');
        setTimeout(function () {
          var s = document.getElementById('search');
          if (s) s.focus();
        }, 60);
      } else {
        var s = document.getElementById('search');
        if (s) s.focus();
      }
      return;
    }

    if (event.key === '?') {
      event.preventDefault();
      openShortcuts();
      return;
    }

    if (event.key === 'g') {
      pendingG = true;
      setTimeout(function () {
        pendingG = false;
      }, 900);
      return;
    }

    if (pendingG) {
      pendingG = false;
      if (event.key === 'h') go('#/');
      if (event.key === 'a') go('#/archiv');
      if (event.key === 'm') go('#/markiert');
      return;
    }

    if (event.key === 't') toggleTheme();
  }

  /* ======================================================================
     Theme
     ====================================================================== */

  function isDark(theme) {
    return (
      theme === 'dark' ||
      (theme === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches)
    );
  }

  function applyTheme(theme) {
    if (theme === 'system') document.documentElement.removeAttribute('data-theme');
    else document.documentElement.setAttribute('data-theme', theme);
    els.themeBtn.title = isDark(theme) ? 'Helles Design' : 'Dunkles Design';
    els.themeBtn.setAttribute('aria-label', els.themeBtn.title);
  }

  function currentTheme() {
    try {
      return localStorage.getItem('kinews.theme') || 'system';
    } catch (err) {
      return 'system';
    }
  }

  function toggleTheme() {
    var next = isDark(currentTheme()) ? 'light' : 'dark';
    try {
      localStorage.setItem('kinews.theme', next);
    } catch (err) {
      /* Ohne Speicher gilt die Wahl nur für diesen Seitenaufruf. */
    }
    applyTheme(next);
  }

  /* ======================================================================
     Start
     ====================================================================== */

  function boot() {
    els.content = document.getElementById('content');
    els.status = document.getElementById('storage-status');
    els.themeBtn = document.getElementById('theme-toggle');
    els.header = document.getElementById('site-header');
    els.footerMeta = document.getElementById('footer-meta');

    /* Wortmarke aus dem Namen in config.js: letzter Teil in der fetten Sans,
       der Rest in der Serife darüber. */
    var parts = String(config.siteName || 'KI-News-Radar').split('-');
    var last = parts.length > 1 ? parts.pop() : '';
    document.getElementById('brand-serif').textContent = parts.join('-');
    document.getElementById('brand-sans').textContent = last;

    applyTheme(currentTheme());
    if ('IntersectionObserver' in window) {
      document.documentElement.classList.add('js-reveal');
    }

    document.addEventListener('click', onClick);
    document.addEventListener('input', onInput);
    document.addEventListener('change', onChange);
    document.addEventListener('keydown', onKeydown);
    window.addEventListener('hashchange', render);

    /* Hintergrund der Kopfzeile erst nach dem ersten Scrollen, ohne
       scroll-Listener. */
    var sentinel = document.getElementById('scroll-sentinel');
    if (sentinel && 'IntersectionObserver' in window) {
      new IntersectionObserver(function (entries) {
        els.header.dataset.scrolled = !entries[0].isIntersecting;
      }).observe(sentinel);
    }

    store.onChange(function () {
      updateStatus();
    });

    /* Skelett in der Form des Heros, damit beim Eintreffen der Daten
       nichts springt. */
    els.content.innerHTML =
      '<div class="container"><div class="skeleton-hero" aria-hidden="true">' +
        '<div class="skeleton__bar" style="width:24%;height:22px"></div>' +
        '<div class="skeleton__bar" style="width:52%;height:clamp(44px,7vw,110px);' +
        'margin-top:30px"></div>' +
        '<div class="skeleton__bar" style="width:40%;height:clamp(44px,7vw,110px);' +
        'margin-top:14px"></div>' +
      '</div></div>';

    Promise.all([
      store.init(),
      data.load(config.dataSources || config.dataDir).catch(function (err) {
        return err;
      })
    ]).then(function (results) {
      var maybeError = results[1];
      updateStatus();

      if (maybeError instanceof Error) {
        els.content.innerHTML = loadErrorState(maybeError);
        return;
      }
      if (data.demoWasEnabled()) data.enableDemo();
      render();
    });

    /* Die Laufschrift misst ihre Breite. Kommen die Webfonts erst nach dem
       ersten Zeichnen, einmal nachmessen. */
    if (document.fonts && document.fonts.ready) {
      document.fonts.ready.then(tuneTicker);
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
