/* ===========================================================================
   Wochendaten laden und in eine durchsuchbare Form bringen.

   Quelle der Wahrheit sind die JSON-Dateien unter data/. Wird die Seite ohne
   Server geöffnet (file://), verbietet der Browser fetch auf lokale Dateien.
   Dann greift data/bundle.js, das per <script> geladen wurde und dieselben
   Daten als Objekt bereitstellt.
   =========================================================================== */

(function () {
  'use strict';

  var CATEGORIES = {
    tools: 'Tools',
    studium: 'Studium',
    alltag: 'Alltag',
    quick: 'Alltagshelfer',
    weitere: 'Nur Titel'
  };

  /* Mit Zeitlimit: hängt GitHub, soll die Seite nicht ewig leer bleiben,
     sondern nach ein paar Sekunden auf die nächste Quelle gehen. */
  function fetchJson(url, timeoutMs) {
    var controller = 'AbortController' in window ? new AbortController() : null;
    var timer = controller
      ? setTimeout(function () {
          controller.abort();
        }, timeoutMs || 8000)
      : null;
    return fetch(url, { cache: 'no-cache', signal: controller ? controller.signal : undefined })
      .then(function (res) {
        if (!res.ok) throw new Error(url + ' -> HTTP ' + res.status);
        return res.json();
      })
      .then(
        function (json) {
          if (timer) clearTimeout(timer);
          return json;
        },
        function (err) {
          if (timer) clearTimeout(timer);
          throw err;
        }
      );
  }

  /* Ein Eintrag, egal ob Hauptthema, Quick Hit oder History-Rest, bekommt
     dieselbe Form. Das hält Suche, Filter und Rendering einfach. */
  function normalise(raw, week, kind) {
    var source = raw.source || {};
    return {
      id: raw.id,
      uid: week.iso_week + '::' + raw.id,
      kind: kind,
      category:
        kind === 'item' ? raw.category || 'tools' : kind === 'quick' ? 'quick' : 'weitere',
      title: raw.title || '',
      summary: raw.summary || '',
      relevance: raw.relevance || null,
      deadline: raw.deadline || null,
      tags: raw.tags || [],
      source: {
        url: source.url || '',
        name: source.name || hostOf(source.url || ''),
        published: source.published || null
      },
      iso_week: week.iso_week,
      week: week.week,
      year: week.year,
      sent_date: week.sent_date,
      demo: !!week.demo,
      /* Vorberechnet, damit die Suche bei jedem Tastendruck nicht neu
         zusammenbaut und kleinschreibt. */
      haystack: [
        raw.title,
        raw.summary,
        raw.relevance ? raw.relevance.studium : '',
        raw.relevance ? raw.relevance.alltag : '',
        (raw.tags || []).join(' '),
        source.name,
        hostOf(source.url || '')
      ]
        .join(' ')
        .toLowerCase()
    };
  }

  function hostOf(url) {
    try {
      return new URL(url).hostname.replace(/^www\./, '');
    } catch (err) {
      return '';
    }
  }

  function expandWeek(week) {
    var entries = [];
    (week.items || []).forEach(function (raw) {
      entries.push(normalise(raw, week, 'item'));
    });
    (week.quick_hits || []).forEach(function (raw) {
      entries.push(normalise(raw, week, 'quick'));
    });
    (week.archive_only || []).forEach(function (raw) {
      entries.push(normalise(raw, week, 'archive'));
    });
    return entries;
  }

  function Data() {
    this.weeks = [];
    this.byWeek = {};
    this.entries = [];
    this.demoActive = false;
    this.offline = false;
  }

  Data.prototype.ingest = function (weeks) {
    var self = this;
    weeks.forEach(function (week) {
      if (self.byWeek[week.iso_week]) return;
      self.byWeek[week.iso_week] = week;
      week.entries = expandWeek(week);
      self.entries = self.entries.concat(week.entries);
    });
    this.weeks = Object.keys(this.byWeek)
      .map(function (k) {
        return self.byWeek[k];
      })
      .sort(function (a, b) {
        return b.iso_week.localeCompare(a.iso_week);
      });
    this.entries.sort(function (a, b) {
      return b.iso_week.localeCompare(a.iso_week);
    });
  };

  /* Alle Wochen aus einer Quelle: erst das Verzeichnis, dann jede Woche. */
  function loadFrom(dir) {
    return fetchJson(dir + 'index.json')
      .then(function (index) {
        var list = (index.weeks || []).slice().sort(function (a, b) {
          return b.iso_week.localeCompare(a.iso_week);
        });
        return Promise.all(
          list.map(function (meta) {
            return fetchJson(dir + 'weeks/' + meta.iso_week + '.json').catch(function () {
              /* Eine kaputte Wochendatei darf nicht das ganze Archiv killen. */
              return null;
            });
          })
        );
      })
      .then(function (weeks) {
        var ok = weeks.filter(Boolean);
        if (!ok.length) throw new Error('Keine Wochendaten in ' + dir);
        return ok;
      });
  }

  /* Quellen der Reihe nach probieren. Die erste, die Wochen liefert, gewinnt.
     Nimmt auch noch einen einzelnen Pfad an, wie ihn ältere config.js-Dateien
     als dataDir angeben. */
  Data.prototype.load = function (sources) {
    var self = this;
    var list = (Array.isArray(sources) ? sources : [sources || 'data/']).filter(Boolean);

    function attempt(i, lastError) {
      if (i >= list.length) {
        return Promise.reject(lastError || new Error('Keine Datenquelle konfiguriert'));
      }
      return loadFrom(list[i]).then(
        function (weeks) {
          self.source = list[i];
          self.fallback = i > 0;
          return weeks;
        },
        function (err) {
          return attempt(i + 1, err);
        }
      );
    }

    return attempt(0)
      .then(function (weeks) {
        self.ingest(weeks);
        return self;
      })
      .catch(function (err) {
        /* file:// oder fehlender Server: auf das mitgelieferte Bündel gehen. */
        var bundle = window.KINEWS_BUNDLE;
        if (bundle && bundle.weeks && bundle.weeks.length) {
          self.offline = true;
          self.ingest(bundle.weeks.slice());
          return self;
        }
        throw err;
      });
  };

  Data.prototype.enableDemo = function () {
    if (this.demoActive) return this;
    var demo = window.KINEWS_DEMO;
    if (!demo || !demo.weeks) return this;
    this.demoActive = true;
    this.ingest(
      demo.weeks.map(function (w) {
        return Object.assign({}, w, { demo: true });
      })
    );
    try {
      localStorage.setItem('kinews.demo', '1');
    } catch (err) {
      /* Ohne Speicher gilt die Demo nur für diese Sitzung. */
    }
    return this;
  };

  Data.prototype.disableDemo = function () {
    try {
      localStorage.removeItem('kinews.demo');
    } catch (err) {
      /* nichts zu tun */
    }
    window.location.reload();
  };

  Data.prototype.demoWasEnabled = function () {
    try {
      return localStorage.getItem('kinews.demo') === '1';
    } catch (err) {
      return false;
    }
  };

  Data.prototype.latest = function () {
    return this.weeks[0] || null;
  };

  Data.prototype.week = function (isoWeek) {
    return this.byWeek[isoWeek] || null;
  };

  Data.prototype.neighbours = function (isoWeek) {
    var i = this.weeks.findIndex(function (w) {
      return w.iso_week === isoWeek;
    });
    return {
      newer: i > 0 ? this.weeks[i - 1] : null,
      older: i >= 0 && i < this.weeks.length - 1 ? this.weeks[i + 1] : null
    };
  };

  Data.prototype.entry = function (uid) {
    return (
      this.entries.find(function (e) {
        return e.uid === uid;
      }) || null
    );
  };

  Data.prototype.years = function () {
    var seen = {};
    this.weeks.forEach(function (w) {
      seen[w.year] = true;
    });
    return Object.keys(seen).sort().reverse();
  };

  window.KINEWS_Data = Data;
  window.KINEWS_CATEGORIES = CATEGORIES;
  window.KINEWS_hostOf = hostOf;
})();
